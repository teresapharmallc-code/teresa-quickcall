# Teresa QuickCall

An Android app for recording patient calls by voice. One tap to start, speak the note, one tap to save. The call lands in your Google Sheet.

This README is written for you, not for a programmer. Follow it in order.

---

## What you have

- **Phase 1 is complete and works**: speak a call, review what was picked up, fix anything wrong, save to Google Sheets, search patients, see today's open calls, and a queue that holds calls when the internet drops.
- **Phase 2 and 3** (callback alarms, orders with multiple products, WhatsApp messages, PIN lock) are not in this build. The buttons for them are visible but greyed out.

---

## Part 1 — Get the APK without installing Android Studio

You do not need a programmer's computer. GitHub will build the app for you, free.

1. Go to github.com and sign in (make a free account if you don't have one).
2. Click the **+** in the top right, then **New repository**. Name it `teresa-quickcall`. Choose **Private**. Click **Create repository**.
3. On the new page, click **uploading an existing file**.
4. Unzip the file I gave you. Open the `TeresaQuickCall` folder, select **everything inside it**, and drag it all into the browser window. (Drag the contents, not the folder itself.)
5. Scroll down and click **Commit changes**.
6. Click the **Actions** tab at the top. You'll see a job called "Build Teresa QuickCall APK" running. Wait about 5 minutes for the green checkmark.
7. Click that finished job, scroll to the bottom, and download **TeresaQuickCall-debug-apk**. Unzip it — inside is `app-debug.apk`.

If the job shows a red X instead, open it and copy the error text to me.

## Part 2 — Install on the pharmacy phones

1. Email or AirDrop `app-debug.apk` to the phone, or put it on Google Drive and open it there.
2. Tap the file. Android will warn about installing from an unknown source — allow it for your browser or Files app.
3. Open **Teresa QuickCall**. It starts in **Sample Mode** with six fictional patients so staff can practise without touching real data.

## Part 3 — Set up the Google Sheet

1. Create a new Google Sheet. Name it something like "Teresa Pharmacy Calls".
2. Look at the address bar. The long code between `/d/` and `/edit` is your **Sheet ID**. Copy it.
3. In that sheet, click **Extensions → Apps Script**.
4. Delete whatever code is in the editor. Open `backend/Code.gs` from the zip, copy all of it, and paste it in.
5. Click the gear icon (**Project Settings**) on the left. Scroll to **Script Properties** → **Add script property**. Add these two:
   - Property `SHEET_ID`, value: the sheet id you copied.
   - Property `APP_SECRET`, value: a long random password you invent. Write it down — you'll type it into the phones. Something like `tp-9f4Kx82mQe-quickcall-2026`.
6. Click **Save**.
7. At the top, choose the function **setupSheets** from the dropdown and press **Run**. Google will ask for permission the first time — click through and allow it. This creates all seven tabs with the right column headings.

## Part 4 — Publish the connection

1. Still in Apps Script, click **Deploy → New deployment**.
2. Click the gear next to "Select type" and choose **Web app**.
3. Set **Execute as: Me**, and **Who has access: Anyone**.
4. Click **Deploy**, approve the permissions, and copy the **Web app URL**. It ends in `/exec`.

"Anyone" sounds alarming but is required — it means anyone can *knock on the door*. Nobody gets in without the APP_SECRET, and your spreadsheet itself stays private. Do not share the URL and secret together.

## Part 5 — Point the phone at your sheet

On each phone:

1. Open the app → **SETTINGS**.
2. Turn **Sample mode** off.
3. Paste the **Web app URL**.
4. Type the **App secret** exactly as you wrote it.
5. Type the **employee name** for that phone (Maria, Ana, whoever uses it). This is what gets written in the Employee column.
6. Tap **SAVE SETTINGS**, then **TEST CONNECTION**. You want "Connected to Google Sheets".

---

## How staff use it

1. Tap the big green **START PATIENT CALL**.
2. Allow the microphone the first time.
3. Speak naturally, all in one go:

   > "John Smith, date of birth March twelfth nineteen sixty-five, calling about a wheelchair. Insurance needs clinical notes. Call him back tomorrow. Phone number seven one eight, five five five, one two three four."

4. The fields fill in as they talk. Tap **STOP** when done.
5. Check the boxes. Tap any one to fix it. Tap a category or status chip to change it.
6. Tap the big green **SAVE CALL**. The phone buzzes and returns to the home screen, ready for the next call.

**Voice commands** — say these on their own, with a pause before and after:
- "save call" — asks for confirmation first, showing the name and DOB in big text. Say "yes" or tap CONFIRM.
- "cancel" — throws the call away
- "new call" — clears and starts fresh
- "mark urgent" — flags it red

**Phrases the app recognizes inside normal speech:** urgent, call back tomorrow, waiting for prescription, needs insurance, needs clinical notes, ready for pickup, delivery requested, completed, prior authorization, out of stock, refill, transfer, prescriber.

---

## When the internet drops

Nothing is lost. The call is written to the phone the moment SAVE is tapped, and a grey bar shows "Saved on phone — waiting to sync". When signal returns the app uploads on its own. Each call carries a unique code, so a retry can never create a double row in your sheet.

---

## Things to know

- **Speech pauses.** Android's recognizer stops after about two seconds of silence. The app restarts it automatically and stitches the sentences together, so a long note works — you may just see a brief gap.
- **Speech needs the Google app** installed and a language pack. Nearly every phone has this. If a phone says speech isn't available, install "Speech Recognition & Synthesis" from the Play Store.
- **English only** in this version.
- **The app never invents information.** If it didn't hear a date of birth, that box stays empty rather than guessed.
- **Screenshots are blocked** on every screen, and the app doesn't appear in the recent-apps preview.
- **Nothing patient-related is written to phone logs**, and there are no ads or analytics.
- Synced calls are deleted from the phone automatically after a week. The sheet keeps everything.

---

## Testing before you go live

Leave Sample Mode on and try these:

1. Say the John Smith sentence above. Check that name, DOB, phone, "Wheelchair" and tomorrow's date all appear.
2. Say only "calling about a shower chair". The name and DOB boxes must be **empty**, not guessed.
3. Turn on airplane mode, save a call, check for the grey "waiting to sync" bar. Turn airplane mode off and watch it clear.
4. Say "save call" and confirm the big name/DOB screen appears before anything saves.
5. Search "smith john" (backwards) and "555 1234" (partial phone) — both should find John Smith.

Then turn Sample Mode off, save one real test call, and confirm the row appears in your Call Log tab.

---

## If something goes wrong

- **"Not authorized"** — the App secret on the phone doesn't match APP_SECRET in Script Properties. Retype both carefully.
- **"Sheet not found"** — you skipped running `setupSheets`, or SHEET_ID is wrong.
- **Nothing appears in the sheet** — check the **Error Log** tab; it records failures without recording patient details.
- **Changed the Apps Script code?** You must click **Deploy → Manage deployments → Edit → New version** for the change to take effect.

---

## Later: matching your existing sheet

If you already have a sheet with different column names, use the **Settings** tab. Add a row like:

| Key | Value |
|---|---|
| Call Log.Status | Call Status |
| Patients.PatientName | Patient Full Name |

The script will then read your column names instead of the defaults. Changes take up to 5 minutes to take effect.
