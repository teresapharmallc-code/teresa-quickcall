/**
 * Teresa QuickCall — Google Apps Script backend
 *
 * WHERE TO PUT YOUR OWN VALUES: open Project Settings > Script Properties
 * and add these two properties. Do NOT type them into this file.
 *
 *   SHEET_ID   = the long id from your Google Sheet URL
 *   APP_SECRET = any long random text you invent; the same text goes into
 *                the phone app under Settings > App secret
 *
 * The sheet itself stays private. This script runs as you and is the only
 * thing that can read it; every request must carry the matching APP_SECRET.
 */

var SHEETS = {
  PATIENTS: 'Patients',
  CALL_LOG: 'Call Log',
  ORDERS: 'Orders',
  ORDER_ITEMS: 'Order Items',
  EMPLOYEES: 'Employees',
  SETTINGS: 'Settings',
  ERROR_LOG: 'Error Log'
};

/** Default column names. The Settings sheet can override any of these. */
var DEFAULT_COLUMNS = {
  'Patients.PatientID': 'PatientID',
  'Patients.PatientName': 'PatientName',
  'Patients.DOB': 'DOB',
  'Patients.Phone': 'Phone',
  'Patients.Address': 'Address',
  'Patients.Notes': 'Notes',
  'Patients.CreatedAt': 'CreatedAt',
  'Patients.UpdatedAt': 'UpdatedAt',
  'Call Log.CallID': 'CallID',
  'Call Log.PatientID': 'PatientID',
  'Call Log.PatientName': 'PatientName',
  'Call Log.DOB': 'DOB',
  'Call Log.Phone': 'Phone',
  'Call Log.CallDate': 'CallDate',
  'Call Log.CallTime': 'CallTime',
  'Call Log.Category': 'Category',
  'Call Log.ProductOrMedication': 'ProductOrMedication',
  'Call Log.OriginalTranscript': 'OriginalTranscript',
  'Call Log.Summary': 'Summary',
  'Call Log.ActionRequired': 'ActionRequired',
  'Call Log.CallbackDate': 'CallbackDate',
  'Call Log.CallbackTime': 'CallbackTime',
  'Call Log.Priority': 'Priority',
  'Call Log.Status': 'Status',
  'Call Log.Employee': 'Employee',
  'Call Log.CreatedAt': 'CreatedAt',
  'Call Log.UpdatedAt': 'UpdatedAt'
};

// ---------------------------------------------------------------- entry point

function doPost(e) {
  var body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch (err) {
    return json({ ok: false, error: 'Bad request body' });
  }

  try {
    if (!checkToken(body.token)) {
      logError('auth', 'Invalid token', '');
      return json({ ok: false, error: 'Not authorized' });
    }

    switch (body.action) {
      case 'ping':            return json({ ok: true });
      case 'saveCall':        return json(saveCall(body.call));
      case 'updateCall':      return json(updateCall(body.call));
      case 'searchPatients':  return json({ ok: true, patients: searchPatients(body.query) });
      case 'patientHistory':  return json({ ok: true, calls: patientHistory(body.patientId) });
      case 'openCallsToday':  return json({ ok: true, calls: openCallsToday() });
      case 'callbacks':       return json({ ok: true, calls: callbacks() });
      case 'totals':          return json({ ok: true, totals: totals() });
      default:                return json({ ok: false, error: 'Unknown action' });
    }
  } catch (err) {
    logError(body ? body.action : 'unknown', err.message, safePayload(body));
    return json({ ok: false, error: 'Server error' });
  }
}

/** GET exists only so you can confirm the deployment is live. It returns no data. */
function doGet() {
  return json({ ok: true, service: 'Teresa QuickCall', note: 'Use POST with a valid token.' });
}

// ------------------------------------------------------------------- security

function checkToken(token) {
  var expected = PropertiesService.getScriptProperties().getProperty('APP_SECRET');
  if (!expected || !token) return false;
  // Constant-length comparison so a wrong secret does not leak its length by timing.
  if (String(token).length !== expected.length) return false;
  var diff = 0;
  for (var i = 0; i < expected.length; i++) {
    diff |= expected.charCodeAt(i) ^ String(token).charCodeAt(i);
  }
  return diff === 0;
}

// ------------------------------------------------------------------ utilities

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function book() {
  var id = PropertiesService.getScriptProperties().getProperty('SHEET_ID');
  if (!id) throw new Error('SHEET_ID script property is missing');
  return SpreadsheetApp.openById(id);
}

function sheet(name) {
  var s = book().getSheetByName(name);
  if (!s) throw new Error('Sheet not found: ' + name);
  return s;
}

/** Reads the header row and returns { fieldName: columnIndex }, honouring Settings overrides. */
function headerMap(sheetName) {
  var s = sheet(sheetName);
  var headers = s.getRange(1, 1, 1, Math.max(1, s.getLastColumn())).getValues()[0];
  var overrides = columnOverrides();
  var map = {};
  for (var field in DEFAULT_COLUMNS) {
    if (field.indexOf(sheetName + '.') !== 0) continue;
    var shortName = field.substring(sheetName.length + 1);
    var wanted = overrides[field] || DEFAULT_COLUMNS[field];
    for (var c = 0; c < headers.length; c++) {
      if (String(headers[c]).trim().toLowerCase() === String(wanted).trim().toLowerCase()) {
        map[shortName] = c;
        break;
      }
    }
  }
  return map;
}

/** The Settings sheet holds key/value pairs like "Call Log.Status" -> "Call Status". */
function columnOverrides() {
  var cache = CacheService.getScriptCache();
  var hit = cache.get('col_overrides');
  if (hit) return JSON.parse(hit);
  var out = {};
  var s = book().getSheetByName(SHEETS.SETTINGS);
  if (s && s.getLastRow() > 1) {
    var rows = s.getRange(2, 1, s.getLastRow() - 1, 2).getValues();
    for (var i = 0; i < rows.length; i++) {
      if (rows[i][0] && rows[i][1]) out[String(rows[i][0]).trim()] = String(rows[i][1]).trim();
    }
  }
  cache.put('col_overrides', JSON.stringify(out), 300);
  return out;
}

function nowStamp() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'MM/dd/yyyy HH:mm:ss');
}

function todayStamp() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'MM/dd/yyyy');
}

function logError(action, message, payload) {
  try {
    var s = book().getSheetByName(SHEETS.ERROR_LOG);
    if (!s) return;
    s.appendRow([nowStamp(), action || '', String(message).substring(0, 400), payload || '']);
  } catch (e) {
    // Never let logging break a request.
  }
}

/** Error log must not contain patient details. Only field names are recorded. */
function safePayload(body) {
  if (!body) return '';
  var keys = [];
  for (var k in body) keys.push(k);
  return 'fields: ' + keys.join(',');
}

function normalizeText(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
}

function digitsOnly(s) {
  return String(s || '').replace(/[^0-9]/g, '');
}

// ------------------------------------------------------------------ save call

function saveCall(call) {
  if (!call || !call.callId) return { ok: false, error: 'Missing callId' };

  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    var s = sheet(SHEETS.CALL_LOG);
    var map = headerMap(SHEETS.CALL_LOG);
    if (map.CallID === undefined) return { ok: false, error: 'Call Log sheet is missing a CallID column' };

    // Duplicate guard: the device generated this id, so a retry finds it already written.
    if (findRowByValue(s, map.CallID, call.callId) > 0) {
      return { ok: true, duplicate: true, callId: call.callId };
    }

    var patientId = call.patientId || ensurePatient(call);

    var width = Math.max(s.getLastColumn(), 1);
    var row = new Array(width).fill('');
    setCell(row, map, 'CallID', call.callId);
    setCell(row, map, 'PatientID', patientId);
    setCell(row, map, 'PatientName', call.patientName);
    setCell(row, map, 'DOB', call.dob);
    setCell(row, map, 'Phone', call.phone);
    setCell(row, map, 'CallDate', call.callDate || todayStamp());
    setCell(row, map, 'CallTime', call.callTime);
    setCell(row, map, 'Category', call.category);
    setCell(row, map, 'ProductOrMedication', call.productOrMedication);
    setCell(row, map, 'OriginalTranscript', call.originalTranscript);
    setCell(row, map, 'Summary', call.summary);
    setCell(row, map, 'ActionRequired', call.actionRequired);
    setCell(row, map, 'CallbackDate', call.callbackDate);
    setCell(row, map, 'CallbackTime', call.callbackTime);
    setCell(row, map, 'Priority', call.priority);
    setCell(row, map, 'Status', call.status);
    setCell(row, map, 'Employee', call.employee);
    setCell(row, map, 'CreatedAt', nowStamp());
    setCell(row, map, 'UpdatedAt', nowStamp());

    s.appendRow(row);
    return { ok: true, callId: call.callId, patientId: patientId };
  } finally {
    lock.releaseLock();
  }
}

function updateCall(call) {
  if (!call || !call.callId) return { ok: false, error: 'Missing callId' };
  var lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    var s = sheet(SHEETS.CALL_LOG);
    var map = headerMap(SHEETS.CALL_LOG);
    var rowIndex = findRowByValue(s, map.CallID, call.callId);
    if (rowIndex <= 0) return saveCall(call); // never lose a call that the sheet does not have

    var width = Math.max(s.getLastColumn(), 1);
    var existing = s.getRange(rowIndex, 1, 1, width).getValues()[0];
    var fields = ['PatientName', 'DOB', 'Phone', 'Category', 'ProductOrMedication', 'Summary',
                  'ActionRequired', 'CallbackDate', 'CallbackTime', 'Priority', 'Status', 'Employee'];
    for (var i = 0; i < fields.length; i++) {
      var f = fields[i];
      var key = f.charAt(0).toLowerCase() + f.slice(1);
      if (map[f] !== undefined && call[key] !== undefined && call[key] !== '') existing[map[f]] = call[key];
    }
    if (map.UpdatedAt !== undefined) existing[map.UpdatedAt] = nowStamp();
    s.getRange(rowIndex, 1, 1, width).setValues([existing]);
    return { ok: true, callId: call.callId };
  } finally {
    lock.releaseLock();
  }
}

function setCell(row, map, field, value) {
  if (map[field] !== undefined) row[map[field]] = value === undefined || value === null ? '' : value;
}

function findRowByValue(s, colIndex, value) {
  if (colIndex === undefined || s.getLastRow() < 2) return -1;
  var col = s.getRange(2, colIndex + 1, s.getLastRow() - 1, 1).getValues();
  for (var i = 0; i < col.length; i++) {
    if (String(col[i][0]) === String(value)) return i + 2;
  }
  return -1;
}

// ------------------------------------------------------------------- patients

/** Finds an existing patient by name+DOB or phone; creates one if there is no match. */
function ensurePatient(call) {
  if (!call.patientName && !call.phone) return '';
  var s = sheet(SHEETS.PATIENTS);
  var map = headerMap(SHEETS.PATIENTS);
  if (map.PatientID === undefined) return '';

  var rows = readRows(s);
  var wantName = normalizeText(call.patientName);
  var wantPhone = digitsOnly(call.phone);

  for (var i = 0; i < rows.length; i++) {
    var name = normalizeText(rows[i][map.PatientName]);
    var dob = String(rows[i][map.DOB] || '');
    var phone = digitsOnly(rows[i][map.Phone]);
    if (wantName && name === wantName && (!call.dob || !dob || dob === call.dob)) return rows[i][map.PatientID];
    if (wantPhone.length >= 10 && phone === wantPhone) return rows[i][map.PatientID];
  }

  var newId = 'P-' + Utilities.getUuid().toUpperCase().substring(0, 8);
  var width = Math.max(s.getLastColumn(), 1);
  var row = new Array(width).fill('');
  setCell(row, map, 'PatientID', newId);
  setCell(row, map, 'PatientName', call.patientName);
  setCell(row, map, 'DOB', call.dob);
  setCell(row, map, 'Phone', call.phone);
  setCell(row, map, 'CreatedAt', nowStamp());
  setCell(row, map, 'UpdatedAt', nowStamp());
  s.appendRow(row);
  return newId;
}

function readRows(s) {
  if (s.getLastRow() < 2) return [];
  return s.getRange(2, 1, s.getLastRow() - 1, Math.max(s.getLastColumn(), 1)).getValues();
}

/**
 * Forgiving search: handles reversed first/last name, missing middle initial,
 * partial phone, and small spelling differences.
 */
function searchPatients(query) {
  var q = String(query || '').trim();
  if (q.length < 2) return [];
  var s = sheet(SHEETS.PATIENTS);
  var map = headerMap(SHEETS.PATIENTS);
  var rows = readRows(s);

  var qDigits = digitsOnly(q);
  var qNorm = normalizeText(q);
  var qTokens = qNorm.split(' ').filter(function (t) { return t.length > 0; });

  var scored = [];
  for (var i = 0; i < rows.length; i++) {
    var name = normalizeText(rows[i][map.PatientName]);
    var dob = String(rows[i][map.DOB] || '');
    var phone = digitsOnly(rows[i][map.Phone]);
    var score = 0;

    if (qDigits.length >= 4 && phone && phone.indexOf(qDigits) >= 0) score = Math.max(score, 0.95);
    if (dob && (dob === q || digitsOnly(dob) === qDigits)) score = Math.max(score, 0.95);

    if (qTokens.length > 0 && name) {
      var nameTokens = name.split(' ');
      var matched = 0;
      for (var t = 0; t < qTokens.length; t++) {
        var best = 0;
        for (var n = 0; n < nameTokens.length; n++) {
          // A single letter is treated as a middle initial and matches loosely.
          if (qTokens[t].length === 1) {
            if (nameTokens[n].charAt(0) === qTokens[t]) best = Math.max(best, 0.8);
            continue;
          }
          if (nameTokens[n].indexOf(qTokens[t]) === 0) { best = 1; break; }
          var sim = similarity(qTokens[t], nameTokens[n]);
          if (sim > best) best = sim;
        }
        if (best >= 0.72) matched += best;
      }
      // Token order does not matter, so "Smith John" finds "John Smith".
      var nameScore = matched / qTokens.length;
      if (nameScore >= 0.7) score = Math.max(score, nameScore * 0.9);
    }

    if (score > 0) {
      scored.push({
        patientId: rows[i][map.PatientID],
        patientName: rows[i][map.PatientName],
        dob: dob,
        phone: String(rows[i][map.Phone] || ''),
        address: map.Address !== undefined ? String(rows[i][map.Address] || '') : '',
        notes: map.Notes !== undefined ? String(rows[i][map.Notes] || '') : '',
        score: score
      });
    }
  }

  scored.sort(function (a, b) { return b.score - a.score; });
  return scored.slice(0, 25);
}

/** Levenshtein-based similarity, 0..1. Catches ordinary typos and misheard spellings. */
function similarity(a, b) {
  if (a === b) return 1;
  if (!a.length || !b.length) return 0;
  var prev = [];
  for (var j = 0; j <= b.length; j++) prev[j] = j;
  for (var i = 1; i <= a.length; i++) {
    var cur = [i];
    for (var k = 1; k <= b.length; k++) {
      var cost = a.charAt(i - 1) === b.charAt(k - 1) ? 0 : 1;
      cur[k] = Math.min(cur[k - 1] + 1, prev[k] + 1, prev[k - 1] + cost);
    }
    prev = cur;
  }
  return 1 - (prev[b.length] / Math.max(a.length, b.length));
}

// ----------------------------------------------------------------- call reads

function callRowToObject(row, map) {
  return {
    callId: String(row[map.CallID] || ''),
    patientId: map.PatientID !== undefined ? String(row[map.PatientID] || '') : '',
    patientName: map.PatientName !== undefined ? String(row[map.PatientName] || '') : '',
    dob: map.DOB !== undefined ? String(row[map.DOB] || '') : '',
    phone: map.Phone !== undefined ? String(row[map.Phone] || '') : '',
    callDate: map.CallDate !== undefined ? String(row[map.CallDate] || '') : '',
    callTime: map.CallTime !== undefined ? String(row[map.CallTime] || '') : '',
    category: map.Category !== undefined ? String(row[map.Category] || '') : '',
    productOrMedication: map.ProductOrMedication !== undefined ? String(row[map.ProductOrMedication] || '') : '',
    originalTranscript: '',
    summary: map.Summary !== undefined ? String(row[map.Summary] || '') : '',
    actionRequired: map.ActionRequired !== undefined ? String(row[map.ActionRequired] || '') : '',
    callbackDate: map.CallbackDate !== undefined ? String(row[map.CallbackDate] || '') : '',
    callbackTime: map.CallbackTime !== undefined ? String(row[map.CallbackTime] || '') : '',
    priority: map.Priority !== undefined ? String(row[map.Priority] || '') : '',
    status: map.Status !== undefined ? String(row[map.Status] || '') : '',
    employee: map.Employee !== undefined ? String(row[map.Employee] || '') : ''
  };
}

function patientHistory(patientId) {
  if (!patientId) return [];
  var s = sheet(SHEETS.CALL_LOG);
  var map = headerMap(SHEETS.CALL_LOG);
  var rows = readRows(s);
  var out = [];
  for (var i = rows.length - 1; i >= 0 && out.length < 50; i--) {
    if (String(rows[i][map.PatientID]) === String(patientId)) out.push(callRowToObject(rows[i], map));
  }
  return out;
}

function openCallsToday() {
  var s = sheet(SHEETS.CALL_LOG);
  var map = headerMap(SHEETS.CALL_LOG);
  var rows = readRows(s);
  var today = todayStamp();
  var out = [];
  for (var i = rows.length - 1; i >= 0 && out.length < 100; i--) {
    var status = String(rows[i][map.Status] || '');
    var date = formatDateCell(rows[i][map.CallDate]);
    if (date === today && status !== 'Completed') out.push(callRowToObject(rows[i], map));
  }
  return out;
}

function callbacks() {
  var s = sheet(SHEETS.CALL_LOG);
  var map = headerMap(SHEETS.CALL_LOG);
  var rows = readRows(s);
  var out = [];
  for (var i = rows.length - 1; i >= 0 && out.length < 100; i--) {
    var cb = formatDateCell(rows[i][map.CallbackDate]);
    var status = String(rows[i][map.Status] || '');
    if (cb && status !== 'Completed') out.push(callRowToObject(rows[i], map));
  }
  return out;
}

function totals() {
  var s = sheet(SHEETS.CALL_LOG);
  var map = headerMap(SHEETS.CALL_LOG);
  var rows = readRows(s);
  var today = todayStamp();
  var t = { callsToday: 0, openCallbacks: 0, urgentCalls: 0, completedCalls: 0 };
  for (var i = 0; i < rows.length; i++) {
    var date = formatDateCell(rows[i][map.CallDate]);
    var status = String(rows[i][map.Status] || '');
    var priority = String(rows[i][map.Priority] || '');
    var cb = formatDateCell(rows[i][map.CallbackDate]);
    if (date === today) {
      t.callsToday++;
      if (status === 'Completed') t.completedCalls++;
      if (priority === 'Urgent') t.urgentCalls++;
    }
    if (cb && status !== 'Completed') t.openCallbacks++;
  }
  return t;
}

/** A cell may hold a real Date or plain text depending on how the sheet is formatted. */
function formatDateCell(v) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), 'MM/dd/yyyy');
  }
  return String(v).trim();
}

// ------------------------------------------------------------------ one-click setup

/**
 * Run this ONCE from the Apps Script editor (choose setupSheets, press Run).
 * It creates every sheet and header row in the spreadsheet named by SHEET_ID.
 * Existing sheets are left alone.
 */
function setupSheets() {
  var ss = book();
  var defs = {
    'Patients': ['PatientID', 'PatientName', 'DOB', 'Phone', 'Address', 'Notes', 'CreatedAt', 'UpdatedAt'],
    'Call Log': ['CallID', 'PatientID', 'PatientName', 'DOB', 'Phone', 'CallDate', 'CallTime', 'Category',
                 'ProductOrMedication', 'OriginalTranscript', 'Summary', 'ActionRequired', 'CallbackDate',
                 'CallbackTime', 'Priority', 'Status', 'Employee', 'CreatedAt', 'UpdatedAt'],
    'Orders': ['OrderID', 'PatientID', 'PatientName', 'DOB', 'Phone', 'OrderDate', 'DeliveryOrPickup',
               'OverallStatus', 'Employee', 'CreatedAt', 'UpdatedAt'],
    'Order Items': ['OrderItemID', 'OrderID', 'Product', 'Quantity', 'Status', 'ReceivedDate', 'CompletedDate', 'Notes'],
    'Employees': ['EmployeeName', 'Active'],
    'Settings': ['Key', 'Value'],
    'Error Log': ['Timestamp', 'Action', 'Message', 'Context']
  };

  for (var name in defs) {
    var s = ss.getSheetByName(name);
    if (!s) {
      s = ss.insertSheet(name);
      s.appendRow(defs[name]);
      s.getRange(1, 1, 1, defs[name].length).setFontWeight('bold');
      s.setFrozenRows(1);
    }
  }
  return 'Sheets ready.';
}
