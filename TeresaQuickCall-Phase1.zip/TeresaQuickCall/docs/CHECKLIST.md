# Phase 1 file checklist

Every file below is complete. No placeholders, no "implement later".

## Build
- [x] settings.gradle.kts
- [x] build.gradle.kts
- [x] gradle.properties
- [x] gradle/libs.versions.toml
- [x] app/build.gradle.kts
- [x] app/proguard-rules.pro
- [x] .gitignore
- [x] .github/workflows/build-apk.yml — builds the APK on GitHub, no Android Studio needed

## Manifest and resources
- [x] app/src/main/AndroidManifest.xml
- [x] res/values/strings.xml
- [x] res/values/themes.xml
- [x] res/xml/network_security_config.xml — blocks all plain HTTP
- [x] res/drawable/ic_launcher.xml

## Parsing (pure Kotlin, unit-tested)
- [x] parser/ParsedCall.kt
- [x] parser/DateParser.kt
- [x] parser/CallParser.kt
- [x] parser/CommandParser.kt

## Data
- [x] data/model/CallRecord.kt
- [x] data/local/PendingCallEntity.kt
- [x] data/local/PendingCallDao.kt
- [x] data/local/QuickCallDatabase.kt
- [x] data/prefs/SecureSettings.kt — EncryptedSharedPreferences
- [x] data/remote/ApiModels.kt
- [x] data/remote/QuickCallApi.kt
- [x] data/repo/CallRepository.kt
- [x] data/repo/SampleData.kt — fictional patients only
- [x] sync/SyncWorker.kt

## Speech
- [x] speech/SpeechEngine.kt — auto-restart across silence gaps

## UI
- [x] ui/theme/Theme.kt
- [x] ui/components/Common.kt
- [x] ui/nav/Routes.kt
- [x] ui/home/HomeViewModel.kt + HomeScreen.kt
- [x] ui/record/RecordViewModel.kt + RecordScreen.kt
- [x] ui/search/SearchViewModel.kt + SearchScreen.kt
- [x] ui/patient/PatientViewModel.kt + PatientScreen.kt
- [x] ui/opencalls/OpenCallsViewModel.kt + OpenCallsScreen.kt
- [x] ui/settings/SettingsViewModel.kt + SettingsScreen.kt
- [x] util/Formats.kt
- [x] QuickCallApp.kt
- [x] MainActivity.kt

## Backend
- [x] backend/Code.gs — auth, save, update, search, history, open calls, callbacks, totals, error log, setupSheets

## Tests
- [x] test/parser/CallParserTest.kt — 7 tests including the spec sentence and the "do not invent" rule
- [x] test/parser/CommandParserTest.kt — 7 tests
- [x] test/parser/DateParserTest.kt — 7 tests

## Docs
- [x] README.md — written for a non-technical owner
- [x] docs/CHECKLIST.md

## Deferred to Phase 2 (buttons greyed out, nothing broken)
- [ ] Callback notifications and alarms
- [ ] Orders and Order Items screens
- [ ] WhatsApp deep-link message
- [ ] Received / missing product tracking

## Deferred to Phase 3
- [ ] PIN and biometric lock, inactivity logout
- [ ] Admin settings beyond local wipe
- [ ] Reporting
