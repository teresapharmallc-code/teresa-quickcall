package com.teresapharmacy.quickcall.data.model

/** One row of the Call Log sheet, as the app sees it. */
data class CallRecord(
    val callId: String,
    val patientId: String = "",
    val patientName: String = "",
    val dob: String = "",
    val phone: String = "",
    val callDate: String = "",
    val callTime: String = "",
    val category: String = "",
    val productOrMedication: String = "",
    val originalTranscript: String = "",
    val summary: String = "",
    val actionRequired: String = "",
    val callbackDate: String = "",
    val callbackTime: String = "",
    val priority: String = "Normal",
    val status: String = "New",
    val employee: String = ""
)

data class Patient(
    val patientId: String = "",
    val patientName: String = "",
    val dob: String = "",
    val phone: String = "",
    val address: String = "",
    val notes: String = ""
)

data class DashboardTotals(
    val callsToday: Int = 0,
    val openCallbacks: Int = 0,
    val urgentCalls: Int = 0,
    val completedCalls: Int = 0
)

object CallStatus {
    const val NEW = "New"
    const val WORKING = "Working"
    const val WAITING_PATIENT = "Waiting for patient"
    const val WAITING_DOCTOR = "Waiting for doctor"
    const val WAITING_INSURANCE = "Waiting for insurance"
    const val CALLBACK = "Callback required"
    const val COMPLETED = "Completed"
    val ALL = listOf(NEW, WORKING, WAITING_PATIENT, WAITING_DOCTOR, WAITING_INSURANCE, CALLBACK, COMPLETED)
}

object CallCategory {
    val ALL = listOf(
        "Refill", "New prescription", "Insurance problem", "Prior authorization",
        "Clinical notes needed", "Product unavailable", "Product ordered",
        "Ready for pickup", "Delivery", "Transfer", "Prescriber call", "Other"
    )
}
