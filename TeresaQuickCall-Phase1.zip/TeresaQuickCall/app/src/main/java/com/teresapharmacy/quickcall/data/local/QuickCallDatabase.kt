package com.teresapharmacy.quickcall.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PendingCallEntity::class], version = 1, exportSchema = false)
abstract class QuickCallDatabase : RoomDatabase() {
    abstract fun pendingCallDao(): PendingCallDao

    companion object {
        @Volatile private var instance: QuickCallDatabase? = null

        fun get(context: Context): QuickCallDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                QuickCallDatabase::class.java,
                "quickcall.db"
            ).fallbackToDestructiveMigration().build().also { instance = it }
        }
    }
}
