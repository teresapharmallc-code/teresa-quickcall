package com.teresapharmacy.quickcall.ui.opencalls

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.remote.CallDto
import com.teresapharmacy.quickcall.data.repo.CallRepository
import com.teresapharmacy.quickcall.data.repo.toDto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class OpenCallsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CallRepository.get(app)

    data class UiState(
        val loading: Boolean = true,
        val calls: List<CallDto> = emptyList(),
        val error: String? = null
    )

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    fun load() {
        _ui.value = UiState(loading = true)
        viewModelScope.launch {
            // Local rows first so calls saved offline are visible right away.
            val local = repo.recentCalls.first().filter { it.status != "Completed" }.map { it.toDto() }
            repo.openCallsToday()
                .onSuccess { remote ->
                    val merged = (local + remote).distinctBy { it.callId }
                    _ui.value = UiState(loading = false, calls = merged)
                }
                .onFailure { _ui.value = UiState(loading = false, calls = local, error = "Showing calls saved on this phone. ${it.message}") }
        }
    }

    fun setStatus(callId: String, status: String) {
        viewModelScope.launch {
            repo.updateStatus(callId, status)
            _ui.value = _ui.value.copy(
                calls = _ui.value.calls.map { if (it.callId == callId) it.copy(status = status) else it }
            )
        }
    }
}
