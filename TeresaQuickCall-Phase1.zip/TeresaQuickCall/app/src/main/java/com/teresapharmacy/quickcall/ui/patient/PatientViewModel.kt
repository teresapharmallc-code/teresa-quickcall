package com.teresapharmacy.quickcall.ui.patient

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.remote.CallDto
import com.teresapharmacy.quickcall.data.remote.PatientDto
import com.teresapharmacy.quickcall.data.repo.CallRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PatientViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CallRepository.get(app)

    data class UiState(
        val loading: Boolean = true,
        val patient: PatientDto? = null,
        val calls: List<CallDto> = emptyList(),
        val error: String? = null
    )

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    fun load(patientId: String) {
        _ui.value = UiState(loading = true)
        viewModelScope.launch {
            val history = repo.patientHistory(patientId)
            val first = history.getOrNull()?.firstOrNull()
            _ui.value = UiState(
                loading = false,
                patient = first?.let {
                    PatientDto(patientId = patientId, patientName = it.patientName, dob = it.dob, phone = it.phone)
                },
                calls = history.getOrElse { emptyList() },
                error = history.exceptionOrNull()?.message
            )
        }
    }
}
