package com.teresapharmacy.quickcall.parser

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

/** Pure-Kotlin date/time extraction from spoken English. No Android dependencies. */
object DateParser {

    val DATE_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy")
    val TIME_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a")

    data class DateMatch(val date: LocalDate, val start: Int, val end: Int, val hadYear: Boolean)
    data class TimeMatch(val time: LocalTime, val start: Int, val end: Int)

    private val MONTHS = mapOf(
        "jan" to 1, "january" to 1, "feb" to 2, "february" to 2, "mar" to 3, "march" to 3,
        "apr" to 4, "april" to 4, "may" to 5, "jun" to 6, "june" to 6, "jul" to 7, "july" to 7,
        "aug" to 8, "august" to 8, "sep" to 9, "sept" to 9, "september" to 9, "oct" to 10, "october" to 10,
        "nov" to 11, "november" to 11, "dec" to 12, "december" to 12
    )
    private const val MONTH_RX = "(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"

    // "march 12 1965", "march 12th, 1965", "march 12"
    private val MONTH_FIRST = Regex("\\b$MONTH_RX\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:,?\\s*(?:of\\s+)?(\\d{4}))?\\b")
    // "12 march 1965", "12th of march"
    private val DAY_FIRST = Regex("\\b(\\d{1,2})(?:st|nd|rd|th)?\\s+(?:of\\s+)?$MONTH_RX\\.?(?:,?\\s*(\\d{4}))?\\b")
    // "3/12/1965", "3-12-65"
    private val NUMERIC = Regex("\\b(\\d{1,2})[/\\-](\\d{1,2})[/\\-](\\d{2,4})\\b")

    private val WEEKDAYS = mapOf(
        "monday" to DayOfWeek.MONDAY, "tuesday" to DayOfWeek.TUESDAY, "wednesday" to DayOfWeek.WEDNESDAY,
        "thursday" to DayOfWeek.THURSDAY, "friday" to DayOfWeek.FRIDAY, "saturday" to DayOfWeek.SATURDAY, "sunday" to DayOfWeek.SUNDAY
    )
    private val NUMBER_WORDS = mapOf(
        "a" to 1, "an" to 1, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10
    )

    /** Finds the first absolute calendar date in [text] (lowercase expected). */
    fun findAbsolute(text: String, now: LocalDate): DateMatch? {
        val candidates = mutableListOf<DateMatch>()
        MONTH_FIRST.find(text)?.let { m ->
            val month = MONTHS[m.groupValues[1]] ?: return@let
            val day = m.groupValues[2].toIntOrNull() ?: return@let
            val year = m.groupValues[3].toIntOrNull()
            buildDate(year ?: now.year, month, day)?.let { candidates.add(DateMatch(it, m.range.first, m.range.last + 1, year != null)) }
        }
        DAY_FIRST.find(text)?.let { m ->
            val day = m.groupValues[1].toIntOrNull() ?: return@let
            val month = MONTHS[m.groupValues[2]] ?: return@let
            val year = m.groupValues[3].toIntOrNull()
            buildDate(year ?: now.year, month, day)?.let { candidates.add(DateMatch(it, m.range.first, m.range.last + 1, year != null)) }
        }
        NUMERIC.find(text)?.let { m ->
            val month = m.groupValues[1].toIntOrNull() ?: return@let
            val day = m.groupValues[2].toIntOrNull() ?: return@let
            var year = m.groupValues[3].toIntOrNull() ?: return@let
            if (year < 100) year += if (year <= now.year % 100) 2000 else 1900
            buildDate(year, month, day)?.let { candidates.add(DateMatch(it, m.range.first, m.range.last + 1, true)) }
        }
        return candidates.minByOrNull { it.start }
    }

    /** Finds a relative or absolute date such as "tomorrow", "next friday", "in 3 days", "march 5". */
    fun findRelative(text: String, now: LocalDate): DateMatch? {
        Regex("\\bday after tomorrow\\b").find(text)?.let { return DateMatch(now.plusDays(2), it.range.first, it.range.last + 1, true) }
        Regex("\\btomorrow\\b").find(text)?.let { return DateMatch(now.plusDays(1), it.range.first, it.range.last + 1, true) }
        Regex("\\b(today|tonight|this afternoon|this evening|later today)\\b").find(text)?.let { return DateMatch(now, it.range.first, it.range.last + 1, true) }
        Regex("\\bin\\s+(\\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten)\\s+(day|week|month)s?\\b").find(text)?.let { m ->
            val n = m.groupValues[1].toIntOrNull() ?: NUMBER_WORDS[m.groupValues[1]] ?: 1
            val d = when (m.groupValues[2]) { "week" -> now.plusWeeks(n.toLong()); "month" -> now.plusMonths(n.toLong()); else -> now.plusDays(n.toLong()) }
            return DateMatch(d, m.range.first, m.range.last + 1, true)
        }
        Regex("\\bnext week\\b").find(text)?.let { return DateMatch(now.plusWeeks(1), it.range.first, it.range.last + 1, true) }
        Regex("\\bnext month\\b").find(text)?.let { return DateMatch(now.plusMonths(1), it.range.first, it.range.last + 1, true) }
        Regex("\\bend of (?:the )?week\\b").find(text)?.let { return DateMatch(now.with(TemporalAdjusters.nextOrSame(DayOfWeek.FRIDAY)), it.range.first, it.range.last + 1, true) }
        Regex("\\b(?:(next|this|on)\\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\\b").find(text)?.let { m ->
            val dow = WEEKDAYS[m.groupValues[2]] ?: return@let
            var d = now.with(TemporalAdjusters.next(dow))
            if (m.groupValues[1] == "next" && d.minusDays(7) > now) d = d.plusWeeks(1)
            return DateMatch(d, m.range.first, m.range.last + 1, true)
        }
        findAbsolute(text, now)?.let { m ->
            var d = m.date
            if (!m.hadYear && d.isBefore(now)) d = d.plusYears(1)
            return m.copy(date = d)
        }
        return null
    }

    /** "at 10", "10 am", "10:30 pm", "noon". Hours 1-6 without am/pm are treated as afternoon (business hours). */
    fun findTime(text: String): TimeMatch? {
        Regex("\\bnoon\\b").find(text)?.let { return TimeMatch(LocalTime.NOON, it.range.first, it.range.last + 1) }
        val rx = Regex("\\b(?:(at|around|by)\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?|o'?clock)?\\b")
        for (m in rx.findAll(text)) {
            val hasAt = m.groupValues[1].isNotEmpty()
            val suffix = m.groupValues[4].replace(".", "").lowercase()
            if (!hasAt && suffix.isEmpty()) continue
            var hour = m.groupValues[2].toIntOrNull() ?: continue
            val minute = m.groupValues[3].toIntOrNull() ?: 0
            if (hour > 23 || minute > 59) continue
            when {
                suffix.startsWith("p") && hour < 12 -> hour += 12
                suffix.startsWith("a") && hour == 12 -> hour = 0
                suffix.isEmpty() && hour in 1..6 -> hour += 12
            }
            return TimeMatch(LocalTime.of(hour, minute), m.range.first, m.range.last + 1)
        }
        return null
    }

    private fun buildDate(year: Int, month: Int, day: Int): LocalDate? =
        try { LocalDate.of(year, month, day) } catch (e: Exception) { null }
}
