package com.teresapharmacy.quickcall.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Status colours from the spec.
val UrgentRed = Color(0xFFC62828)
val CallbackOrange = Color(0xFFE65100)
val WaitingYellow = Color(0xFFF9A825)
val CompletedGreen = Color(0xFF2E7D32)
val NewBlue = Color(0xFF1565C0)
val ActionGreen = Color(0xFF1B8A3E)

private val Light = lightColorScheme(
    primary = ActionGreen,
    onPrimary = Color.White,
    secondary = NewBlue,
    background = Color(0xFFF7F7F7),
    surface = Color.White,
    onSurface = Color(0xFF111111),
    error = UrgentRed
)

private val Dark = darkColorScheme(
    primary = ActionGreen,
    onPrimary = Color.White,
    secondary = Color(0xFF64B5F6),
    error = Color(0xFFEF5350)
)

/** Large text everywhere: this is read at arm's length across a counter. */
private val BigTypography = Typography(
    displaySmall = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 19.sp),
    bodyMedium = TextStyle(fontSize = 17.sp),
    labelLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Bold)
)

fun statusColor(status: String, priority: String = "Normal"): Color = when {
    priority.equals("Urgent", true) -> UrgentRed
    status.equals("Callback required", true) -> CallbackOrange
    status.startsWith("Waiting", true) -> WaitingYellow
    status.equals("Completed", true) -> CompletedGreen
    else -> NewBlue
}

@Composable
fun QuickCallTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        typography = BigTypography,
        content = content
    )
}
