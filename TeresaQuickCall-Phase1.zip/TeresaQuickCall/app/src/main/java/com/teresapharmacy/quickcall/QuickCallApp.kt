package com.teresapharmacy.quickcall

import android.app.Application
import com.teresapharmacy.quickcall.sync.SyncWorker

class QuickCallApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Anything left unsynced from a previous session goes out as soon as there is network.
        SyncWorker.enqueue(this)
    }
}
