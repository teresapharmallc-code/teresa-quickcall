package com.teresapharmacy.quickcall.data.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Token, endpoint URL and employee name live in EncryptedSharedPreferences,
 * which is backed by the Android Keystore. Nothing here is ever logged.
 */
class SecureSettings(context: Context) {

    private val prefs: SharedPreferences = run {
        val key = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "quickcall_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var scriptUrl: String
        get() = prefs.getString(KEY_URL, "").orEmpty()
        set(v) = prefs.edit().putString(KEY_URL, v.trim()).apply()

    var appToken: String
        get() = prefs.getString(KEY_TOKEN, "").orEmpty()
        set(v) = prefs.edit().putString(KEY_TOKEN, v.trim()).apply()

    var employeeName: String
        get() = prefs.getString(KEY_EMPLOYEE, "").orEmpty()
        set(v) = prefs.edit().putString(KEY_EMPLOYEE, v.trim()).apply()

    /** Sample mode uses fictional patients and never touches the network. */
    var sampleMode: Boolean
        get() = prefs.getBoolean(KEY_SAMPLE, true)
        set(v) = prefs.edit().putBoolean(KEY_SAMPLE, v).apply()

    var vibrateOnSave: Boolean
        get() = prefs.getBoolean(KEY_VIBRATE, true)
        set(v) = prefs.edit().putBoolean(KEY_VIBRATE, v).apply()

    val isConfigured: Boolean
        get() = sampleMode || (scriptUrl.startsWith("https://") && appToken.isNotEmpty())

    fun wipe() = prefs.edit().clear().apply()

    companion object {
        private const val KEY_URL = "script_url"
        private const val KEY_TOKEN = "app_token"
        private const val KEY_EMPLOYEE = "employee_name"
        private const val KEY_SAMPLE = "sample_mode"
        private const val KEY_VIBRATE = "vibrate_on_save"
    }
}
