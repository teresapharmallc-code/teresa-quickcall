package com.teresapharmacy.quickcall.ui.search

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.remote.PatientDto
import com.teresapharmacy.quickcall.data.repo.CallRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SearchViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CallRepository.get(app)

    data class UiState(
        val query: String = "",
        val loading: Boolean = false,
        val results: List<PatientDto> = emptyList(),
        val searched: Boolean = false,
        val error: String? = null
    )

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui

    fun setQuery(q: String) { _ui.value = _ui.value.copy(query = q) }

    fun search() {
        val q = _ui.value.query.trim()
        if (q.length < 2) { _ui.value = _ui.value.copy(error = "Type at least 2 characters."); return }
        _ui.value = _ui.value.copy(loading = true, error = null)
        viewModelScope.launch {
            repo.searchPatients(q)
                .onSuccess { _ui.value = _ui.value.copy(loading = false, results = it, searched = true) }
                .onFailure { _ui.value = _ui.value.copy(loading = false, error = it.message ?: "Search failed", searched = true) }
        }
    }
}
