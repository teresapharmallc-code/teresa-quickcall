package com.teresapharmacy.quickcall.ui.record

import android.Manifest
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.data.model.CallCategory
import com.teresapharmacy.quickcall.data.prefs.SecureSettings
import com.teresapharmacy.quickcall.ui.components.BigButton
import com.teresapharmacy.quickcall.ui.theme.ActionGreen
import com.teresapharmacy.quickcall.ui.theme.UrgentRed

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RecordScreen(
    onDone: () -> Unit,
    vm: RecordViewModel = viewModel()
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val speechState by vm.speech.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showExitWarning by remember { mutableStateOf(false) }
    var micGranted by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        micGranted = granted
        if (granted) vm.startListening(fresh = true)
    }

    // One tap on Home already brought us here; recording starts on its own.
    LaunchedEffect(Unit) {
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(ui.savedMessage) {
        val msg = ui.savedMessage ?: return@LaunchedEffect
        if (SecureSettings(context).vibrateOnSave) vibrate(context)
        onDone()
    }

    Scaffold(
        bottomBar = {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (ui.listening) {
                    BigButton("STOP", { vm.stopListening() }, container = Color(0xFF424242))
                } else {
                    BigButton(
                        if (ui.hasContent) "CONTINUE RECORDING" else "START RECORDING",
                        { vm.startListening(fresh = !ui.hasContent) },
                        container = Color(0xFF424242)
                    )
                }
                BigButton("SAVE CALL", { vm.save() }, container = ActionGreen, enabled = ui.hasContent && !ui.saving, height = 80)
            }
        }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .padding(horizontal = 14.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (ui.listening) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                    Box(Modifier.size(16.dp).background(UrgentRed, RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(10.dp))
                    Text("Listening — speak now", style = MaterialTheme.typography.titleMedium)
                }
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }

            speechState.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
            }

            Text(
                ui.transcript.ifBlank { "Say the patient name, date of birth, what they need, and any callback." },
                style = MaterialTheme.typography.headlineSmall,
                color = if (ui.transcript.isBlank()) Color.Gray else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            if (ui.hasContent) {
                HorizontalDivider()
                Text("Check and fix", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(vertical = 8.dp))

                EditField("Patient name", ui.parsed.patientName) { vm.edit("name", it) }
                EditField("Date of birth", ui.parsed.dob) { vm.edit("dob", it) }
                EditField("Phone", ui.parsed.phone) { vm.edit("phone", it) }
                EditField("Product / medication", ui.parsed.product) { vm.edit("product", it) }
                EditField("Reason", ui.parsed.reason) { vm.edit("reason", it) }
                EditField("Action required", ui.parsed.actionRequired) { vm.edit("action", it) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) { EditField("Callback date", ui.parsed.callbackDate) { vm.edit("callbackDate", it) } }
                    Box(Modifier.weight(1f)) { EditField("Callback time", ui.parsed.callbackTime) { vm.edit("callbackTime", it) } }
                }

                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Urgent", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Switch(
                        checked = ui.parsed.priority.equals("Urgent", true),
                        onCheckedChange = { vm.edit("priority", if (it) "Urgent" else "Normal") }
                    )
                }

                Text("Category", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CallCategory.ALL.forEach { c ->
                        FilterChip(
                            selected = ui.parsed.category == c,
                            onClick = { vm.edit("category", if (ui.parsed.category == c) "" else c) },
                            label = { Text(c) }
                        )
                    }
                }

                Text("Status", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.teresapharmacy.quickcall.data.model.CallStatus.ALL.forEach { s ->
                        FilterChip(
                            selected = ui.parsed.status == s,
                            onClick = { vm.edit("status", s) },
                            label = { Text(s) }
                        )
                    }
                }
                Spacer(Modifier.height(90.dp))
            }
        }
    }

    // Voice-triggered save: never write without an explicit yes.
    if (ui.awaitingConfirm) {
        AlertDialog(
            onDismissRequest = { vm.cancelConfirm() },
            title = { Text("Save this call?") },
            text = {
                Column {
                    Text(ui.parsed.patientName.ifBlank { "(no name)" }, style = MaterialTheme.typography.displaySmall)
                    Text("DOB ${ui.parsed.dob.ifBlank { "—" }}", style = MaterialTheme.typography.headlineSmall)
                    Text(ui.parsed.product.ifBlank { ui.parsed.reason }, style = MaterialTheme.typography.bodyLarge)
                    Text("Say yes to save, or no to fix.", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 10.dp))
                }
            },
            confirmButton = { TextButton({ vm.confirmSave() }) { Text("CONFIRM") } },
            dismissButton = { TextButton({ vm.cancelConfirm() }) { Text("FIX") } }
        )
    }

    if (showExitWarning) {
        AlertDialog(
            onDismissRequest = { showExitWarning = false },
            title = { Text("Leave without saving?") },
            text = { Text("This call has not been saved. It will be lost.") },
            confirmButton = { TextButton({ showExitWarning = false; vm.clear(); onDone() }) { Text("DISCARD") } },
            dismissButton = { TextButton({ showExitWarning = false }) { Text("STAY") } }
        )
    }

    androidx.activity.compose.BackHandler(enabled = true) {
        if (ui.hasContent) showExitWarning = true else onDone()
    }
}

@Composable
private fun EditField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = label != "Reason",
        textStyle = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    )
}

private fun vibrate(context: Context) {
    val effect = VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        manager.defaultVibrator.vibrate(effect)
    } else {
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(effect)
    }
}
