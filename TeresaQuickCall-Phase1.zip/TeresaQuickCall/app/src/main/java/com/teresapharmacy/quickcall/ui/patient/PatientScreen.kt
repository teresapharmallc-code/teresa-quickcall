package com.teresapharmacy.quickcall.ui.patient

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.ui.components.StatusPill

@Composable
fun PatientScreen(patientId: String, vm: PatientViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    LaunchedEffect(patientId) { vm.load(patientId) }

    Column(Modifier.fillMaxSize()) {
        // Name and DOB stay pinned so the wrong record is obvious immediately.
        Surface(color = MaterialTheme.colorScheme.primary, tonalElevation = 4.dp) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text(
                    ui.patient?.patientName ?: "Loading…",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Text(
                    "DOB ${ui.patient?.dob ?: "—"}   ${ui.patient?.phone ?: ""}",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }

        if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        ui.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(14.dp)) }

        Text("Previous calls", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(14.dp))

        LazyColumn(
            Modifier.padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ui.calls) { c ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("${c.callDate} ${c.callTime}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            StatusPill(c.status, c.priority)
                        }
                        if (c.productOrMedication.isNotBlank()) Text(c.productOrMedication, style = MaterialTheme.typography.bodyLarge)
                        if (c.summary.isNotBlank()) Text(c.summary, style = MaterialTheme.typography.bodyMedium)
                        if (c.actionRequired.isNotBlank()) Text("Action: ${c.actionRequired}", style = MaterialTheme.typography.bodyMedium)
                        if (c.callbackDate.isNotBlank()) Text("Callback: ${c.callbackDate} ${c.callbackTime}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}
