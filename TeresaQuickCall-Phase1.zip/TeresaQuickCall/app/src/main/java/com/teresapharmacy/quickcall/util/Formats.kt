package com.teresapharmacy.quickcall.util

import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

object Formats {
    private val DATE = DateTimeFormatter.ofPattern("MM/dd/yyyy", Locale.US)
    private val TIME = DateTimeFormatter.ofPattern("h:mm a", Locale.US)

    fun today(): String = LocalDate.now().format(DATE)
    fun now(): String = LocalTime.now().format(TIME)

    /** Device-generated id. This is what makes a retry safe — the server writes it once. */
    fun newCallId(): String = "C-" + UUID.randomUUID().toString().uppercase(Locale.US).take(13)

    fun firstName(fullName: String): String = fullName.trim().split(" ").firstOrNull().orEmpty()

    fun digitsOnly(s: String): String = s.filter { it.isDigit() }
}
