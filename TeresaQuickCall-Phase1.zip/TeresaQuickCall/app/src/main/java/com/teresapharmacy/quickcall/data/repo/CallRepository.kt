package com.teresapharmacy.quickcall.data.repo

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.teresapharmacy.quickcall.data.local.PendingCallDao
import com.teresapharmacy.quickcall.data.local.PendingCallEntity
import com.teresapharmacy.quickcall.data.local.QuickCallDatabase
import com.teresapharmacy.quickcall.data.prefs.SecureSettings
import com.teresapharmacy.quickcall.data.remote.ApiRequest
import com.teresapharmacy.quickcall.data.remote.ApiResponse
import com.teresapharmacy.quickcall.data.remote.CallDto
import com.teresapharmacy.quickcall.data.remote.PatientDto
import com.teresapharmacy.quickcall.data.remote.QuickCallApi
import com.teresapharmacy.quickcall.data.remote.TotalsDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Single source of truth. Every save goes to Room first and returns immediately,
 * so the employee is never waiting on the network. Upload happens after.
 */
class CallRepository(
    private val context: Context,
    private val dao: PendingCallDao,
    private val settings: SecureSettings,
    private val api: QuickCallApi
) {

    val unsyncedCount: Flow<Int> = dao.unsyncedCount()
    val recentCalls: Flow<List<PendingCallEntity>> = dao.recent()

    /** Writes locally and returns at once. Returns true if it also reached the server. */
    suspend fun saveCall(entity: PendingCallEntity): Boolean = withContext(Dispatchers.IO) {
        dao.upsert(entity)
        if (settings.sampleMode) {
            dao.markSynced(entity.callId)
            return@withContext true
        }
        if (!isOnline()) return@withContext false
        pushOne(entity)
    }

    suspend fun syncPending(): Int = withContext(Dispatchers.IO) {
        if (settings.sampleMode) return@withContext 0
        var sent = 0
        for (row in dao.unsynced()) {
            if (pushOne(row)) sent++
        }
        dao.purgeSyncedBefore(System.currentTimeMillis() - PURGE_AFTER_MS)
        sent
    }

    private suspend fun pushOne(row: PendingCallEntity): Boolean = try {
        val res = api.post(
            settings.scriptUrl,
            ApiRequest(
                action = if (row.isUpdate) "updateCall" else "saveCall",
                token = settings.appToken,
                employee = settings.employeeName,
                call = row.toDto()
            )
        )
        // A duplicate is a success: the server already has this callId.
        if (res.ok || res.duplicate) {
            dao.markSynced(row.callId); true
        } else {
            dao.markFailed(row.callId, res.error.orEmpty().take(120)); false
        }
    } catch (e: Exception) {
        dao.markFailed(row.callId, e.javaClass.simpleName)
        false
    }

    suspend fun updateStatus(callId: String, status: String): Boolean = withContext(Dispatchers.IO) {
        dao.updateStatus(callId, status)
        val row = dao.byId(callId) ?: return@withContext false
        if (settings.sampleMode) { dao.markSynced(callId); return@withContext true }
        if (!isOnline()) return@withContext false
        pushOne(row)
    }

    suspend fun searchPatients(query: String): Result<List<PatientDto>> = withContext(Dispatchers.IO) {
        if (settings.sampleMode) return@withContext Result.success(localSearch(query))
        runCatching {
            val res = api.post(
                settings.scriptUrl,
                ApiRequest(action = "searchPatients", token = settings.appToken, query = query, employee = settings.employeeName)
            )
            if (!res.ok) throw IllegalStateException(res.error ?: "Search failed")
            res.patients.orEmpty()
        }
    }

    suspend fun patientHistory(patientId: String): Result<List<CallDto>> = withContext(Dispatchers.IO) {
        if (settings.sampleMode) {
            return@withContext Result.success(SampleData.calls.filter { it.patientId == patientId })
        }
        runCatching {
            val res = api.post(
                settings.scriptUrl,
                ApiRequest(action = "patientHistory", token = settings.appToken, patientId = patientId, employee = settings.employeeName)
            )
            if (!res.ok) throw IllegalStateException(res.error ?: "History failed")
            res.calls.orEmpty()
        }
    }

    suspend fun openCallsToday(): Result<List<CallDto>> = withContext(Dispatchers.IO) {
        if (settings.sampleMode) return@withContext Result.success(SampleData.calls.filter { it.status != "Completed" })
        runCatching {
            val res = api.post(settings.scriptUrl, ApiRequest(action = "openCallsToday", token = settings.appToken, employee = settings.employeeName))
            if (!res.ok) throw IllegalStateException(res.error ?: "Load failed")
            res.calls.orEmpty()
        }
    }

    suspend fun totals(): Result<TotalsDto> = withContext(Dispatchers.IO) {
        if (settings.sampleMode) {
            val s = SampleData.calls
            return@withContext Result.success(
                TotalsDto(
                    callsToday = s.size,
                    openCallbacks = s.count { it.status == "Callback required" },
                    urgentCalls = s.count { it.priority == "Urgent" },
                    completedCalls = s.count { it.status == "Completed" }
                )
            )
        }
        runCatching {
            val res: ApiResponse = api.post(settings.scriptUrl, ApiRequest(action = "totals", token = settings.appToken, employee = settings.employeeName))
            if (!res.ok) throw IllegalStateException(res.error ?: "Totals failed")
            res.totals ?: TotalsDto()
        }
    }

    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val res = api.post(settings.scriptUrl, ApiRequest(action = "ping", token = settings.appToken, employee = settings.employeeName))
            if (!res.ok) throw IllegalStateException(res.error ?: "Rejected")
            "Connected"
        }
    }

    suspend fun wipeLocal() = withContext(Dispatchers.IO) { dao.wipe() }

    private fun localSearch(query: String): List<PatientDto> {
        val q = query.trim().lowercase(Locale.US)
        if (q.isEmpty()) return emptyList()
        val digits = q.filter { it.isDigit() }
        return SampleData.patients.filter { p ->
            val name = p.patientName.lowercase(Locale.US)
            val tokens = q.split(" ").filter { it.isNotBlank() }
            tokens.all { name.contains(it) } ||
                (digits.length >= 4 && p.phone.filter { it.isDigit() }.contains(digits)) ||
                p.dob.contains(q)
        }
    }

    fun isOnline(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    companion object {
        private const val PURGE_AFTER_MS = 7L * 24 * 60 * 60 * 1000 // keep synced rows one week

        @Volatile private var instance: CallRepository? = null

        fun get(context: Context): CallRepository = instance ?: synchronized(this) {
            instance ?: CallRepository(
                context.applicationContext,
                QuickCallDatabase.get(context).pendingCallDao(),
                SecureSettings(context.applicationContext),
                QuickCallApi.create()
            ).also { instance = it }
        }
    }
}

fun PendingCallEntity.toDto() = CallDto(
    callId = callId, patientId = patientId, patientName = patientName, dob = dob, phone = phone,
    callDate = callDate, callTime = callTime, category = category, productOrMedication = productOrMedication,
    originalTranscript = originalTranscript, summary = summary, actionRequired = actionRequired,
    callbackDate = callbackDate, callbackTime = callbackTime, priority = priority, status = status, employee = employee
)
