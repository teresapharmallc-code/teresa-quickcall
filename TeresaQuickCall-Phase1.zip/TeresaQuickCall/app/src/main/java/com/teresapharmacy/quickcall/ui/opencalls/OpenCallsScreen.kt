package com.teresapharmacy.quickcall.ui.opencalls

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.data.model.CallStatus
import com.teresapharmacy.quickcall.ui.components.StatusPill

@Composable
fun OpenCallsScreen(vm: OpenCallsViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var statusFor by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Today's open calls", style = MaterialTheme.typography.headlineSmall)
        if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
        ui.error?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error) }
        if (!ui.loading && ui.calls.isEmpty()) Text("Nothing open. Good.", style = MaterialTheme.typography.titleMedium)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(ui.calls) { c ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.patientName.ifBlank { "(no name)" }, style = MaterialTheme.typography.titleLarge)
                                Text("DOB ${c.dob.ifBlank { "—" }}", style = MaterialTheme.typography.bodyMedium)
                            }
                            StatusPill(c.status, c.priority)
                        }
                        if (c.productOrMedication.isNotBlank()) Text(c.productOrMedication, style = MaterialTheme.typography.bodyLarge)
                        if (c.actionRequired.isNotBlank()) Text("Action: ${c.actionRequired}", style = MaterialTheme.typography.bodyMedium)
                        TextButton({ statusFor = c.callId }) { Text("CHANGE STATUS") }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }

    statusFor?.let { id ->
        AlertDialog(
            onDismissRequest = { statusFor = null },
            title = { Text("Set status") },
            text = {
                Column {
                    CallStatus.ALL.forEach { s ->
                        TextButton({ vm.setStatus(id, s); statusFor = null }, Modifier.fillMaxWidth()) {
                            Text(s, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ statusFor = null }) { Text("CLOSE") } }
        )
    }
}
