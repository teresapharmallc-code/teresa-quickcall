package com.teresapharmacy.quickcall.ui.record

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.local.PendingCallEntity
import com.teresapharmacy.quickcall.data.prefs.SecureSettings
import com.teresapharmacy.quickcall.data.repo.CallRepository
import com.teresapharmacy.quickcall.parser.CallParser
import com.teresapharmacy.quickcall.parser.CommandParser
import com.teresapharmacy.quickcall.parser.ParsedCall
import com.teresapharmacy.quickcall.speech.SpeechEngine
import com.teresapharmacy.quickcall.sync.SyncWorker
import com.teresapharmacy.quickcall.util.Formats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RecordViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = CallRepository.get(app)
    private val settings = SecureSettings(app)
    val speech = SpeechEngine(app)

    data class UiState(
        val parsed: ParsedCall = ParsedCall(),
        val transcript: String = "",
        val listening: Boolean = false,
        val awaitingConfirm: Boolean = false,
        val saving: Boolean = false,
        val savedMessage: String? = null,
        val error: String? = null,
        val hasContent: Boolean = false
    )

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var lastHandledSegment = ""

    init {
        viewModelScope.launch {
            speech.state.collect { s ->
                handleSpeech(s)
            }
        }
    }

    private fun handleSpeech(s: SpeechEngine.State) {
        // A short final segment may be a command rather than dictation.
        if (s.lastSegment.isNotBlank() && s.lastSegment != lastHandledSegment) {
            lastHandledSegment = s.lastSegment
            if (_ui.value.awaitingConfirm) {
                when (CommandParser.detectConfirmation(s.lastSegment)) {
                    CommandParser.Confirmation.YES -> { confirmSave(); return }
                    CommandParser.Confirmation.NO -> { _ui.value = _ui.value.copy(awaitingConfirm = false); return }
                    null -> {}
                }
            } else {
                when (CommandParser.detect(s.lastSegment)) {
                    CommandParser.Command.SAVE -> { requestSaveByVoice(); return }
                    CommandParser.Command.CANCEL -> { clear(); return }
                    CommandParser.Command.NEW_CALL -> { clear(); startListening(fresh = true); return }
                    CommandParser.Command.MARK_URGENT -> {
                        _ui.value = _ui.value.copy(parsed = _ui.value.parsed.copy(priority = "Urgent"))
                        return
                    }
                    null -> {}
                }
            }
        }

        val text = s.displayText
        val parsed = if (text.isBlank()) ParsedCall() else CallParser.parse(text)
        // Keep any manual edits the employee already made: only fill blanks from speech.
        val merged = mergeKeepingEdits(_ui.value.parsed, parsed)
        _ui.value = _ui.value.copy(
            transcript = text,
            parsed = merged,
            listening = s.listening,
            hasContent = text.isNotBlank(),
            error = s.error
        )
    }

    /** Fields the employee typed are marked by editedKeys and are never overwritten by later speech. */
    private val editedKeys = mutableSetOf<String>()

    private fun mergeKeepingEdits(current: ParsedCall, fresh: ParsedCall): ParsedCall {
        var out = fresh
        for (key in editedKeys) {
            val kept = when (key) {
                "name" -> current.patientName; "dob" -> current.dob; "phone" -> current.phone
                "product" -> current.product; "reason" -> current.reason; "action" -> current.actionRequired
                "callbackDate" -> current.callbackDate; "callbackTime" -> current.callbackTime
                "priority" -> current.priority; "status" -> current.status; "category" -> current.category
                else -> ""
            }
            out = out.with(key, kept)
        }
        return out
    }

    fun edit(key: String, value: String) {
        editedKeys.add(key)
        _ui.value = _ui.value.copy(parsed = _ui.value.parsed.with(key, value))
    }

    fun startListening(fresh: Boolean) {
        if (fresh) { editedKeys.clear(); lastHandledSegment = "" }
        speech.start(fresh)
    }

    fun stopListening() = speech.stop()

    fun clear() {
        editedKeys.clear()
        lastHandledSegment = ""
        speech.reset()
        _ui.value = UiState()
    }

    fun dismissSaved() { _ui.value = _ui.value.copy(savedMessage = null) }

    /** Voice-triggered save always shows the confirm screen first. */
    private fun requestSaveByVoice() {
        speech.stop()
        _ui.value = _ui.value.copy(awaitingConfirm = true)
        speech.start(fresh = false) // keep listening so "yes" can be spoken
    }

    fun cancelConfirm() { _ui.value = _ui.value.copy(awaitingConfirm = false) }

    fun confirmSave() {
        _ui.value = _ui.value.copy(awaitingConfirm = false)
        save()
    }

    fun save() {
        val state = _ui.value
        if (state.saving) return
        if (state.transcript.isBlank() && state.parsed.patientName.isBlank()) {
            _ui.value = state.copy(error = "Nothing recorded yet.")
            return
        }
        _ui.value = state.copy(saving = true)
        speech.stop()

        val p = state.parsed
        val entity = PendingCallEntity(
            callId = Formats.newCallId(),
            patientName = p.patientName,
            dob = p.dob,
            phone = p.phone,
            callDate = Formats.today(),
            callTime = Formats.now(),
            category = p.category,
            productOrMedication = p.product,
            originalTranscript = state.transcript,
            summary = p.reason,
            actionRequired = p.actionRequired,
            callbackDate = p.callbackDate,
            callbackTime = p.callbackTime,
            priority = p.priority,
            status = p.status,
            employee = settings.employeeName
        )

        viewModelScope.launch {
            val uploaded = repo.saveCall(entity)
            if (!uploaded) SyncWorker.enqueue(getApplication())
            editedKeys.clear()
            lastHandledSegment = ""
            speech.reset()
            _ui.value = UiState(savedMessage = if (uploaded) "Saved" else "Saved on phone — waiting to sync")
        }
    }

    override fun onCleared() {
        speech.destroy()
        super.onCleared()
    }
}
