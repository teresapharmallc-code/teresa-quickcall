package com.teresapharmacy.quickcall.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A call saved on the phone. Rows stay here until the server confirms them.
 * callId is generated on the device and is what makes retries safe: the backend
 * ignores a second submission carrying an id it has already written.
 */
@Entity(tableName = "pending_calls")
data class PendingCallEntity(
    @PrimaryKey val callId: String,
    val patientId: String = "",
    val patientName: String = "",
    val dob: String = "",
    val phone: String = "",
    val callDate: String = "",
    val callTime: String = "",
    val category: String = "",
    val productOrMedication: String = "",
    val originalTranscript: String = "",
    val summary: String = "",
    val actionRequired: String = "",
    val callbackDate: String = "",
    val callbackTime: String = "",
    val priority: String = "Normal",
    val status: String = "New",
    val employee: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val synced: Boolean = false,
    val attempts: Int = 0,
    val lastError: String = "",
    /** Set when this row is an edit of an already-synced call rather than a new one. */
    val isUpdate: Boolean = false
)
