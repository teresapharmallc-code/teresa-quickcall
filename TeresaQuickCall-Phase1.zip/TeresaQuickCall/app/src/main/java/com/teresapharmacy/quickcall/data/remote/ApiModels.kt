package com.teresapharmacy.quickcall.data.remote

import com.squareup.moshi.JsonClass

/** One request shape for every action; Apps Script switches on `action`. */
@JsonClass(generateAdapter = true)
data class ApiRequest(
    val action: String,
    val token: String,
    val employee: String = "",
    val call: CallDto? = null,
    val query: String? = null,
    val patientId: String? = null,
    val callId: String? = null,
    val status: String? = null
)

@JsonClass(generateAdapter = true)
data class CallDto(
    val callId: String,
    val patientId: String = "",
    val patientName: String = "",
    val dob: String = "",
    val phone: String = "",
    val callDate: String = "",
    val callTime: String = "",
    val category: String = "",
    val productOrMedication: String = "",
    val originalTranscript: String = "",
    val summary: String = "",
    val actionRequired: String = "",
    val callbackDate: String = "",
    val callbackTime: String = "",
    val priority: String = "",
    val status: String = "",
    val employee: String = ""
)

@JsonClass(generateAdapter = true)
data class PatientDto(
    val patientId: String = "",
    val patientName: String = "",
    val dob: String = "",
    val phone: String = "",
    val address: String = "",
    val notes: String = "",
    val score: Double = 0.0
)

@JsonClass(generateAdapter = true)
data class TotalsDto(
    val callsToday: Int = 0,
    val openCallbacks: Int = 0,
    val urgentCalls: Int = 0,
    val completedCalls: Int = 0
)

@JsonClass(generateAdapter = true)
data class ApiResponse(
    val ok: Boolean = false,
    val error: String? = null,
    val duplicate: Boolean = false,
    val callId: String? = null,
    val patientId: String? = null,
    val totals: TotalsDto? = null,
    val patients: List<PatientDto>? = null,
    val calls: List<CallDto>? = null
)
