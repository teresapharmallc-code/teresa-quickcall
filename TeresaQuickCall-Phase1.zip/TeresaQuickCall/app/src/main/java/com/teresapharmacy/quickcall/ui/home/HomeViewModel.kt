package com.teresapharmacy.quickcall.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.prefs.SecureSettings
import com.teresapharmacy.quickcall.data.remote.TotalsDto
import com.teresapharmacy.quickcall.data.repo.CallRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = CallRepository.get(app)
    private val settings = SecureSettings(app)

    val pending: StateFlow<Int> = repo.unsyncedCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _totals = MutableStateFlow(TotalsDto())
    val totals: StateFlow<TotalsDto> = _totals

    private val _needsSetup = MutableStateFlow(false)
    val needsSetup: StateFlow<Boolean> = _needsSetup

    fun refresh() {
        _needsSetup.value = !settings.isConfigured
        viewModelScope.launch {
            repo.totals().onSuccess { _totals.value = it }
        }
    }

    fun isOnline() = repo.isOnline()
    fun sampleMode() = settings.sampleMode
}
