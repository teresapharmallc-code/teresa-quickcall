package com.teresapharmacy.quickcall.parser

import java.time.LocalDate
import java.util.Locale

/**
 * Turns a spoken sentence into structured fields.
 * Pure Kotlin so it can be unit-tested without Android.
 *
 * Example input:
 *  "John Smith, date of birth March 12 1965, calling about wheelchair. Insurance needs clinical notes.
 *   Call him back tomorrow. Phone number 718-555-1234."
 */
object CallParser {

    private class Rule(
        pattern: String,
        val category: String? = null,
        val status: String? = null,
        val action: String? = null,
        val priority: String? = null
    ) { val rx = Regex(pattern) }

    // Order matters only for ties; the earliest match in the sentence wins for category/action.
    private val RULES = listOf(
        Rule("\\b(mark (?:as )?urgent|urgent|emergency|asap|right away|immediately)\\b", priority = "Urgent"),
        Rule("\\b(clinical notes|chart notes|progress notes|office notes)\\b", category = "Clinical notes needed", status = "Waiting for doctor", action = "Needs clinical notes"),
        Rule("\\b(prior auth(?:orization)?|pa needed|needs pa)\\b", category = "Prior authorization", status = "Waiting for insurance", action = "Prior authorization needed"),
        Rule("\\b(insurance|medicaid|medicare|copay|rejected|rejection)\\b", category = "Insurance problem", status = "Waiting for insurance", action = "Needs insurance"),
        Rule("\\b(waiting (?:for|on) (?:the |a )?(?:prescription|script|rx|doctor)|no prescription|needs? (?:a )?(?:new )?prescription|prescription needed)\\b", category = "New prescription", status = "Waiting for doctor", action = "Waiting for prescription"),
        Rule("\\b(new prescription|new rx|new script)\\b", category = "New prescription"),
        Rule("\\b(refill|refilled)\\b", category = "Refill"),
        Rule("\\b(ready for pick ?up|is ready|are ready|ready to pick ?up)\\b", category = "Ready for pickup", status = "Callback required", action = "Notify patient: ready for pickup"),
        Rule("\\b(deliver(?:y|ed)?(?: requested)?)\\b", category = "Delivery", action = "Delivery requested"),
        Rule("\\b(transfer(?:red)?)\\b", category = "Transfer"),
        Rule("\\b(prescriber|doctor'?s office|call (?:the )?(?:doctor|md|prescriber|office)|fax (?:the )?(?:doctor|office))\\b", category = "Prescriber call", status = "Waiting for doctor", action = "Call prescriber"),
        Rule("\\b(out of stock|unavailable|not available|back ?ordered|backorder|not in stock|missing)\\b", category = "Product unavailable", action = "Product unavailable"),
        Rule("\\b(has been ordered|was ordered|product ordered|we ordered|ordered it|on order)\\b", category = "Product ordered", status = "Working", action = "Product ordered"),
        Rule("\\b(completed|complete|resolved|all set|taken care of)\\b", status = "Completed")
    )

    private val PHONE = Regex("(?:\\+?1[\\s.\\-]?)?\\(?(\\d{3})\\)?[\\s.\\-]?(\\d{3})[\\s.\\-]?(\\d{4})\\b")
    private val PHONE_WORDS = Regex("\\b(?:phone number|telephone number|phone|telephone|cell(?: phone)?|number)\\b(?:\\s+is)?[:\\s]*")
    private val DOB_WORDS = Regex("\\b(?:date of birth|dob|d\\.o\\.b\\.?|birth ?date|birthday|born on|born)\\b(?:\\s+is)?[:\\s,]*")
    private val CALLBACK = Regex("\\b(?:call ?back|callback|follow ?up|call (?:him|her|them|the patient|patient)(?: back)?|call (?:tomorrow|today|tonight|on|next|in\\s+\\w+|monday|tuesday|wednesday|thursday|friday|saturday|sunday)|reach out|contact (?:him|her|them|the patient|patient))\\b")
    private val PRODUCT = Regex("\\b(?:calling about|asking about|question about|regarding|about|refill (?:of|on|for)|needs? (?:a |an |the |his |her )?refill (?:of|on|for)|prescription for|rx for)\\s+(?:a |an |the |his |her |their |some )?([a-z][a-z0-9'\\- ]{1,40}?)(?=[.,;!?]|\\s+(?:and|but|because|needs?|insurance|call|phone|please|for|is|was|which|that)\\b|$)")
    private val NAME_STOP = Regex("\\b(date of birth|dob|born|calling|is calling|called|phone|needs|about|wants|asked|asking|says|new order|order)\\b")
    private val NAME_LEAD = Regex("^(?:new order for|order for|patient|this is|call from|caller|caller is|the patient|mrs?\\.?|ms\\.?|miss|dr\\.?|okay|ok|so|um|uh)\\s+", RegexOption.IGNORE_CASE)

    fun parse(raw: String, now: LocalDate = LocalDate.now()): ParsedCall {
        var text = raw.replace(Regex("\\s+"), " ").trim()
        if (text.isEmpty()) return ParsedCall()
        var lower = text.lowercase(Locale.US)

        // ---- Phone ----
        var phone = ""
        PHONE.find(lower)?.let { m ->
            phone = "${m.groupValues[1]}-${m.groupValues[2]}-${m.groupValues[3]}"
            text = text.removeRange(m.range)
            lower = text.lowercase(Locale.US)
            PHONE_WORDS.findAll(lower).lastOrNull()?.let { w ->
                if (w.range.first > m.range.first - 40) { text = text.removeRange(w.range); lower = text.lowercase(Locale.US) }
            }
        }

        // ---- Date of birth ----
        var dob = ""
        val dobWord = DOB_WORDS.find(lower)
        if (dobWord != null) {
            val after = lower.substring(dobWord.range.last + 1)
            val m = DateParser.findAbsolute(after.take(48), now)
            if (m != null && m.start <= 3) {
                dob = m.date.format(DateParser.DATE_FMT)
                val end = dobWord.range.last + 1 + m.end
                text = text.removeRange(dobWord.range.first, end)
            } else {
                text = text.removeRange(dobWord.range)
            }
            lower = text.lowercase(Locale.US)
        } else {
            // A full date with a past year and no keyword is almost always a DOB.
            DateParser.findAbsolute(lower, now)?.let { m ->
                if (m.hadYear && m.date.year < now.year) {
                    dob = m.date.format(DateParser.DATE_FMT)
                    text = text.removeRange(m.start, m.end)
                    lower = text.lowercase(Locale.US)
                }
            }
        }

        // ---- Callback date / time ----
        var callbackDate = ""
        var callbackTime = ""
        var hasCallback = false
        CALLBACK.find(lower)?.let { m ->
            hasCallback = true
            val rest = lower.substring(m.range.first).split(Regex("[.;!?]"))[0]
            DateParser.findRelative(rest, now)?.let { callbackDate = it.date.format(DateParser.DATE_FMT) }
            DateParser.findTime(rest)?.let { callbackTime = it.time.format(DateParser.TIME_FMT) }
            if (callbackDate.isEmpty() && callbackTime.isNotEmpty()) callbackDate = now.format(DateParser.DATE_FMT)
        }

        // ---- Keyword rules (category / status / action / priority) ----
        var category = ""
        var action = ""
        var ruleStatus = ""
        var completed = false
        var priority = "Normal"
        var bestCat = Int.MAX_VALUE
        var bestAct = Int.MAX_VALUE
        var bestStatus = Int.MAX_VALUE
        for (r in RULES) {
            val m = r.rx.find(lower) ?: continue
            if (r.priority != null) priority = r.priority
            if (r.status == "Completed") completed = true
            if (r.category != null && m.range.first < bestCat) { bestCat = m.range.first; category = r.category }
            if (r.action != null && m.range.first < bestAct) { bestAct = m.range.first; action = r.action }
            if (r.status != null && r.status != "Completed" && m.range.first < bestStatus) { bestStatus = m.range.first; ruleStatus = r.status }
        }
        val status = when {
            completed -> "Completed"
            hasCallback -> "Callback required"
            ruleStatus.isNotEmpty() -> ruleStatus
            else -> "New"
        }
        if (hasCallback && action.isEmpty()) action = "Call back"
        if (hasCallback && action.isNotEmpty() && action != "Call back" && !action.contains("Call back")) action = "$action; call back"

        // ---- Product ----
        var product = ""
        PRODUCT.find(lower)?.let { product = cleanPhrase(it.groupValues[1]) }

        // ---- Patient name ----
        var name = ""
        run {
            var head = text.split(Regex("[,.;!?]"))[0].trim()
            head = NAME_LEAD.replace(head, "").trim()
            val stop = NAME_STOP.find(head.lowercase(Locale.US))
            if (stop != null) head = head.substring(0, stop.range.first).trim()
            val words = head.split(" ").filter { it.isNotBlank() }
            val nameWords = words.takeWhile { w -> w.all { it.isLetter() || it == '\'' || it == '-' || it == '.' } }.take(4)
            if (nameWords.size in 1..4 && words.size <= 6) {
                name = nameWords.joinToString(" ") { w -> w.lowercase(Locale.US).replaceFirstChar { it.titlecase(Locale.US) } }
            }
        }

        // ---- Reason / summary ----
        val sentences = text.split(Regex("(?<=[.;!?])\\s+")).map { it.trim().trim(',', ' ') }.filter { it.isNotEmpty() }
        val reasonSentence = sentences.firstOrNull { s ->
            val l = s.lowercase(Locale.US)
            l.contains("about") || l.contains("regarding") || l.contains("calling") || l.contains("refill") || l.contains("needs")
        } ?: sentences.firstOrNull() ?: ""
        var reason = reasonSentence
        if (name.isNotEmpty() && reason.lowercase(Locale.US).startsWith(name.lowercase(Locale.US))) {
            reason = reason.substring(name.length).trim().trimStart(',', ' ')
        }
        reason = cleanPhrase(reason, keepCase = true)
        if (reason.isEmpty() && product.isNotEmpty()) reason = "Calling about $product"

        return ParsedCall(
            patientName = name,
            dob = dob,
            phone = phone,
            product = product,
            reason = reason.take(200),
            actionRequired = action,
            callbackDate = callbackDate,
            callbackTime = callbackTime,
            priority = priority,
            status = status,
            category = category
        )
    }

    private fun cleanPhrase(s: String, keepCase: Boolean = false): String {
        var out = s.trim().trim(',', '.', ';', ' ')
        out = out.replace(Regex("\\s+"), " ")
        if (!keepCase) out = out.replaceFirstChar { it.titlecase(Locale.US) }
        return out
    }
}
