package com.teresapharmacy.quickcall.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teresapharmacy.quickcall.data.prefs.SecureSettings
import com.teresapharmacy.quickcall.data.repo.CallRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = SecureSettings(app)
    private val repo = CallRepository.get(app)

    data class UiState(
        val url: String = "",
        val token: String = "",
        val employee: String = "",
        val sampleMode: Boolean = true,
        val vibrate: Boolean = true,
        val testing: Boolean = false,
        val message: String? = null
    )

    private val _ui = MutableStateFlow(
        UiState(settings.scriptUrl, settings.appToken, settings.employeeName, settings.sampleMode, settings.vibrateOnSave)
    )
    val ui: StateFlow<UiState> = _ui

    fun setUrl(v: String) { _ui.value = _ui.value.copy(url = v) }
    fun setToken(v: String) { _ui.value = _ui.value.copy(token = v) }
    fun setEmployee(v: String) { _ui.value = _ui.value.copy(employee = v) }
    fun setSample(v: Boolean) { _ui.value = _ui.value.copy(sampleMode = v) }
    fun setVibrate(v: Boolean) { _ui.value = _ui.value.copy(vibrate = v) }

    fun save() {
        val s = _ui.value
        if (!s.sampleMode && !s.url.startsWith("https://")) {
            _ui.value = s.copy(message = "The web app URL must start with https://")
            return
        }
        settings.scriptUrl = s.url
        settings.appToken = s.token
        settings.employeeName = s.employee
        settings.sampleMode = s.sampleMode
        settings.vibrateOnSave = s.vibrate
        _ui.value = s.copy(message = "Settings saved")
    }

    fun test() {
        save()
        if (_ui.value.sampleMode) { _ui.value = _ui.value.copy(message = "Sample mode is on — no connection needed."); return }
        _ui.value = _ui.value.copy(testing = true)
        viewModelScope.launch {
            repo.testConnection()
                .onSuccess { _ui.value = _ui.value.copy(testing = false, message = "Connected to Google Sheets") }
                .onFailure { _ui.value = _ui.value.copy(testing = false, message = "Failed: ${it.message}") }
        }
    }

    fun wipeLocal() {
        viewModelScope.launch {
            repo.wipeLocal()
            _ui.value = _ui.value.copy(message = "Local data deleted from this phone")
        }
    }

    fun clearMessage() { _ui.value = _ui.value.copy(message = null) }
}
