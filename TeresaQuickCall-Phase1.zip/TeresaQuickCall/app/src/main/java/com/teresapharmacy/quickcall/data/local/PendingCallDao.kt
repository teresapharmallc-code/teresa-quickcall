package com.teresapharmacy.quickcall.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingCallDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(call: PendingCallEntity)

    @Query("SELECT * FROM pending_calls WHERE synced = 0 ORDER BY createdAt ASC")
    suspend fun unsynced(): List<PendingCallEntity>

    @Query("SELECT COUNT(*) FROM pending_calls WHERE synced = 0")
    fun unsyncedCount(): Flow<Int>

    @Query("SELECT * FROM pending_calls ORDER BY createdAt DESC LIMIT 200")
    fun recent(): Flow<List<PendingCallEntity>>

    @Query("SELECT * FROM pending_calls WHERE callId = :id LIMIT 1")
    suspend fun byId(id: String): PendingCallEntity?

    @Query("UPDATE pending_calls SET synced = 1, lastError = '' WHERE callId = :id")
    suspend fun markSynced(id: String)

    @Query("UPDATE pending_calls SET attempts = attempts + 1, lastError = :error WHERE callId = :id")
    suspend fun markFailed(id: String, error: String)

    @Query("UPDATE pending_calls SET status = :status, synced = 0, isUpdate = 1 WHERE callId = :id")
    suspend fun updateStatus(id: String, status: String)

    /** Housekeeping: synced rows older than the cutoff are removed so little patient data sits on the phone. */
    @Query("DELETE FROM pending_calls WHERE synced = 1 AND createdAt < :cutoff")
    suspend fun purgeSyncedBefore(cutoff: Long)

    @Query("DELETE FROM pending_calls")
    suspend fun wipe()
}
