package com.teresapharmacy.quickcall.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.ui.components.BigButton
import com.teresapharmacy.quickcall.ui.theme.UrgentRed

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var confirmWipe by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sample mode", style = MaterialTheme.typography.titleMedium)
                Text("Practice with fictional patients. Nothing is sent to your sheet.", style = MaterialTheme.typography.bodyMedium)
            }
            Switch(checked = ui.sampleMode, onCheckedChange = vm::setSample)
        }

        OutlinedTextField(
            value = ui.url, onValueChange = vm::setUrl,
            label = { Text("Apps Script web app URL") },
            supportingText = { Text("Ends in /exec") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = ui.token, onValueChange = vm::setToken,
            label = { Text("App secret") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions.Default,
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = ui.employee, onValueChange = vm::setEmployee,
            label = { Text("Employee name (this phone)") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Vibrate after save", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Switch(checked = ui.vibrate, onCheckedChange = vm::setVibrate)
        }

        if (ui.testing) LinearProgressIndicator(Modifier.fillMaxWidth())
        BigButton("SAVE SETTINGS", { vm.save() })
        BigButton("TEST CONNECTION", { vm.test() }, container = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(20.dp))
        BigButton("DELETE LOCAL DATA ON THIS PHONE", { confirmWipe = true }, container = UrgentRed, height = 56)
        Text(
            "The Google Sheet is not touched. Only the copy stored on this phone is removed. Unsynced calls will be lost.",
            style = MaterialTheme.typography.bodyMedium
        )
        Spacer(Modifier.height(30.dp))
    }

    ui.message?.let { msg ->
        AlertDialog(
            onDismissRequest = { vm.clearMessage() },
            text = { Text(msg, style = MaterialTheme.typography.titleMedium) },
            confirmButton = { TextButton({ vm.clearMessage() }) { Text("OK") } }
        )
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Delete local data?") },
            text = { Text("Any call not yet synced will be lost permanently.") },
            confirmButton = { TextButton({ vm.wipeLocal(); confirmWipe = false }) { Text("DELETE") } },
            dismissButton = { TextButton({ confirmWipe = false }) { Text("CANCEL") } }
        )
    }
}
