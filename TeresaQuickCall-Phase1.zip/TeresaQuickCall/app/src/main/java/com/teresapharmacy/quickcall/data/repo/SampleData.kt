package com.teresapharmacy.quickcall.data.repo

import com.teresapharmacy.quickcall.data.remote.CallDto
import com.teresapharmacy.quickcall.data.remote.PatientDto

/** Fictional patients only. Used when Sample Mode is on so staff can practise safely. */
object SampleData {
    val patients = listOf(
        PatientDto("P-1001", "John Smith", "03/12/1965", "718-555-1234", "12 Grand Ave", "Prefers morning calls"),
        PatientDto("P-1002", "Maria Lopez", "07/08/1958", "718-555-9876", "48 Park St", ""),
        PatientDto("P-1003", "Robert Chen", "11/30/1972", "917-555-4412", "3 Ocean Pkwy", "Delivery only"),
        PatientDto("P-1004", "Aisha Rahman", "01/22/1990", "347-555-7788", "77 Bay Ridge Ave", ""),
        PatientDto("P-1005", "Daniel O'Neill", "06/05/1948", "718-555-3321", "9 Court St", "Hard of hearing"),
        PatientDto("P-1006", "Grace Adeyemi", "09/14/1983", "646-555-2093", "210 Fulton St", "")
    )

    val calls = listOf(
        CallDto(
            callId = "C-SAMPLE-1", patientId = "P-1001", patientName = "John Smith", dob = "03/12/1965",
            phone = "718-555-1234", callDate = "09/07/2026", callTime = "9:15 AM", category = "Insurance problem",
            productOrMedication = "Wheelchair", summary = "Calling about wheelchair",
            actionRequired = "Needs clinical notes; call back", callbackDate = "09/08/2026",
            priority = "Normal", status = "Callback required", employee = "Sample"
        ),
        CallDto(
            callId = "C-SAMPLE-2", patientId = "P-1003", patientName = "Robert Chen", dob = "11/30/1972",
            phone = "917-555-4412", callDate = "09/07/2026", callTime = "10:02 AM", category = "Refill",
            productOrMedication = "Lisinopril", summary = "Refill request", actionRequired = "",
            priority = "Normal", status = "Working", employee = "Sample"
        ),
        CallDto(
            callId = "C-SAMPLE-3", patientId = "P-1005", patientName = "Daniel O'Neill", dob = "06/05/1948",
            phone = "718-555-3321", callDate = "09/07/2026", callTime = "10:40 AM", category = "Product unavailable",
            productOrMedication = "Shower chair", summary = "Shower chair out of stock",
            actionRequired = "Product unavailable", priority = "Urgent", status = "Waiting for patient", employee = "Sample"
        )
    )
}
