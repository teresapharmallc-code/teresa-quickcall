package com.teresapharmacy.quickcall.parser

/**
 * Everything the parser can extract from one spoken sentence.
 * Blank string = not recognized. The parser never invents values.
 */
data class ParsedCall(
    val patientName: String = "",
    val dob: String = "",            // MM/dd/yyyy
    val phone: String = "",          // 718-555-1234
    val product: String = "",
    val reason: String = "",
    val actionRequired: String = "",
    val callbackDate: String = "",   // MM/dd/yyyy
    val callbackTime: String = "",   // 10:00 AM
    val priority: String = "Normal",
    val status: String = "New",
    val category: String = ""
) {
    fun with(key: String, value: String): ParsedCall = when (key) {
        "name" -> copy(patientName = value)
        "dob" -> copy(dob = value)
        "phone" -> copy(phone = value)
        "product" -> copy(product = value)
        "reason" -> copy(reason = value)
        "action" -> copy(actionRequired = value)
        "callbackDate" -> copy(callbackDate = value)
        "callbackTime" -> copy(callbackTime = value)
        "priority" -> copy(priority = value)
        "status" -> copy(status = value)
        "category" -> copy(category = value)
        else -> this
    }
}
