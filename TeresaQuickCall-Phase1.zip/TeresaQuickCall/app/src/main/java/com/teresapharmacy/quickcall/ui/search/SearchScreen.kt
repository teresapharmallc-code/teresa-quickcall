package com.teresapharmacy.quickcall.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.ui.components.BigButton

@Composable
fun SearchScreen(
    onPatient: (String) -> Unit,
    vm: SearchViewModel = viewModel()
) {
    val ui by vm.ui.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        OutlinedTextField(
            value = ui.query,
            onValueChange = vm::setQuery,
            label = { Text("Name, DOB, phone or order number") },
            textStyle = MaterialTheme.typography.headlineSmall,
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        BigButton("SEARCH", { vm.search() })
        Spacer(Modifier.height(10.dp))

        if (ui.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        ui.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        if (ui.searched && ui.results.isEmpty() && !ui.loading) {
            Text("No matching patient found.", style = MaterialTheme.typography.titleMedium)
        }
        if (ui.results.size > 1) {
            Text(
                "${ui.results.size} patients match — pick the right one.",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ui.results) { p ->
                Card(
                    Modifier.fillMaxWidth().clickable { onPatient(p.patientId) }
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(p.patientName, style = MaterialTheme.typography.titleLarge)
                        Text("DOB ${p.dob.ifBlank { "—" }}", style = MaterialTheme.typography.bodyLarge)
                        Text(p.phone.ifBlank { "no phone" }, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
