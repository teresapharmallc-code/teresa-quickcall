package com.teresapharmacy.quickcall.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.teresapharmacy.quickcall.ui.components.BigButton
import com.teresapharmacy.quickcall.ui.components.DashboardTile
import com.teresapharmacy.quickcall.ui.components.SyncBanner
import com.teresapharmacy.quickcall.ui.theme.*

@Composable
fun HomeScreen(
    onRecord: () -> Unit,
    onSearch: () -> Unit,
    onOpenCalls: () -> Unit,
    onSettings: () -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val totals by vm.totals.collectAsStateWithLifecycle()
    val pending by vm.pending.collectAsStateWithLifecycle()
    val needsSetup by vm.needsSetup.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.refresh() }

    Column(Modifier.fillMaxSize()) {
        SyncBanner(pending, vm.isOnline())

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DashboardTile("Calls today", totals.callsToday, NewBlue, Modifier.weight(1f))
                DashboardTile("Callbacks", totals.openCallbacks, CallbackOrange, Modifier.weight(1f))
                DashboardTile("Urgent", totals.urgentCalls, UrgentRed, Modifier.weight(1f))
                DashboardTile("Done", totals.completedCalls, CompletedGreen, Modifier.weight(1f))
            }

            if (vm.sampleMode()) {
                Card(colors = CardDefaults.cardColors(containerColor = WaitingYellow)) {
                    Text(
                        "SAMPLE MODE — fictional patients, nothing is sent to your Google Sheet. Turn off in Settings.",
                        Modifier.padding(12.dp), color = Color.Black, style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else if (needsSetup) {
                Card(colors = CardDefaults.cardColors(containerColor = UrgentRed)) {
                    Text(
                        "Not set up yet. Open Settings and enter the web app URL and secret.",
                        Modifier.padding(12.dp), color = Color.White, style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            BigButton("START PATIENT CALL", onRecord, container = ActionGreen, height = 110)
            BigButton("SEARCH PATIENT", onSearch, container = NewBlue)
            BigButton("TODAY'S OPEN CALLS", onOpenCalls, container = WaitingYellow, contentColor = Color.Black)
            BigButton("CALLBACKS", onOpenCalls, container = CallbackOrange)
            BigButton("NEW ORDER", { }, container = Color(0xFF9E9E9E), enabled = false)
            BigButton("MISSING PRODUCTS", { }, container = Color(0xFF9E9E9E), enabled = false)
            Text(
                "New Order and Missing Products arrive in Phase 2.",
                style = MaterialTheme.typography.bodyMedium, color = Color.Gray
            )
            BigButton("SETTINGS", onSettings, container = Color(0xFF455A64), height = 56)
        }
    }
}
