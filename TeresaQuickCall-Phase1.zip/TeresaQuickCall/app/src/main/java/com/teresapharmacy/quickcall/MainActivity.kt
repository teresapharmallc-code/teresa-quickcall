package com.teresapharmacy.quickcall

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.teresapharmacy.quickcall.ui.home.HomeScreen
import com.teresapharmacy.quickcall.ui.nav.Routes
import com.teresapharmacy.quickcall.ui.opencalls.OpenCallsScreen
import com.teresapharmacy.quickcall.ui.patient.PatientScreen
import com.teresapharmacy.quickcall.ui.record.RecordScreen
import com.teresapharmacy.quickcall.ui.search.SearchScreen
import com.teresapharmacy.quickcall.ui.settings.SettingsScreen
import com.teresapharmacy.quickcall.ui.theme.QuickCallTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots and hides the app from the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent {
            QuickCallTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    QuickCallNavHost()
                }
            }
        }
    }
}

@Composable
fun QuickCallNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onRecord = { nav.navigate(Routes.RECORD) },
                onSearch = { nav.navigate(Routes.SEARCH) },
                onOpenCalls = { nav.navigate(Routes.OPEN_CALLS) },
                onSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.RECORD) {
            RecordScreen(onDone = { nav.popBackStack(Routes.HOME, inclusive = false) })
        }
        composable(Routes.SEARCH) {
            SearchScreen(onPatient = { nav.navigate(Routes.patient(it)) })
        }
        composable(
            Routes.PATIENT,
            arguments = listOf(navArgument("patientId") { type = NavType.StringType })
        ) { entry ->
            PatientScreen(entry.arguments?.getString("patientId").orEmpty())
        }
        composable(Routes.OPEN_CALLS) { OpenCallsScreen() }
        composable(Routes.SETTINGS) { SettingsScreen() }
    }
}
