package com.teresapharmacy.quickcall.parser

import java.util.Locale

/** Detects short voice commands. A command must be the whole spoken segment (ignoring filler). */
object CommandParser {
    enum class Command { SAVE, CANCEL, NEW_CALL, MARK_URGENT }
    enum class Confirmation { YES, NO }

    private val FILLER = Regex("^(?:please|okay|ok|so|um|uh|hey|claude|app)\\s+|[.,!?]+$")

    fun detect(segment: String): Command? {
        val s = normalize(segment)
        return when {
            s.matches(Regex("(save|save call|save the call|save this call|save it|save now)")) -> Command.SAVE
            s.matches(Regex("(cancel|cancel call|cancel the call|discard|never mind|nevermind)")) -> Command.CANCEL
            s.matches(Regex("(new call|start new call|next call|start over)")) -> Command.NEW_CALL
            s.matches(Regex("(mark urgent|mark as urgent|mark it urgent|urgent|this is urgent)")) -> Command.MARK_URGENT
            else -> null
        }
    }

    fun detectConfirmation(segment: String): Confirmation? {
        val s = normalize(segment)
        return when {
            s.matches(Regex("(yes|yes save|confirm|confirmed|correct|save|that's right|that is right|right|yep|yeah|go ahead)")) -> Confirmation.YES
            s.matches(Regex("(no|cancel|fix|wrong|not right|that's wrong|that is wrong|nope|stop)")) -> Confirmation.NO
            else -> null
        }
    }

    private fun normalize(segment: String): String {
        var s = segment.trim().lowercase(Locale.US)
        s = FILLER.replace(s, "").trim()
        s = s.replace(Regex("[.,!?]+$"), "").trim()
        return s
    }
}
