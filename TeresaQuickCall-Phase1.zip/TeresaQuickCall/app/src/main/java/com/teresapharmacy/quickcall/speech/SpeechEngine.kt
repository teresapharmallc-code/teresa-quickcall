package com.teresapharmacy.quickcall.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Wraps Android SpeechRecognizer and hides its biggest limitation: it stops after
 * a short silence. When that happens while the employee is still recording, we
 * restart it and append the next phrase, so one long spoken note becomes one transcript.
 */
class SpeechEngine(private val context: Context) {

    data class State(
        val listening: Boolean = false,
        val finalText: String = "",
        val partialText: String = "",
        val lastSegment: String = "",
        val rmsLevel: Float = 0f,
        val error: String? = null,
        val available: Boolean = true
    ) {
        val displayText: String
            get() = listOf(finalText, partialText).filter { it.isNotBlank() }.joinToString(" ")
    }

    private val _state = MutableStateFlow(State(available = SpeechRecognizer.isRecognitionAvailable(context)))
    val state: StateFlow<State> = _state

    private var recognizer: SpeechRecognizer? = null
    private var wantListening = false
    /** Incremented on every accepted segment so the screen can react to a new command. */
    private var segmentCounter = 0

    fun start(fresh: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = _state.value.copy(available = false, error = "Speech recognition is not available on this phone.")
            return
        }
        if (fresh) _state.value = State(available = true)
        wantListening = true
        launchRecognizer()
    }

    fun stop() {
        wantListening = false
        recognizer?.stopListening()
        _state.value = _state.value.copy(listening = false)
    }

    fun reset() {
        wantListening = false
        recognizer?.cancel()
        _state.value = State(available = SpeechRecognizer.isRecognitionAvailable(context))
    }

    fun destroy() {
        wantListening = false
        recognizer?.destroy()
        recognizer = null
    }

    /** Lets the screen inject a correction without going through the microphone. */
    fun overwriteText(text: String) {
        _state.value = _state.value.copy(finalText = text, partialText = "")
    }

    private fun launchRecognizer() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = _state.value.copy(listening = true, error = null)
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                _state.value = _state.value.copy(rmsLevel = rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                // Silence timeouts are normal mid-note: restart quietly and keep going.
                val recoverable = error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                if (wantListening && recoverable) {
                    launchRecognizer()
                    return
                }
                val message = when (error) {
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Speech service could not be reached. Offline recognition may need to be downloaded in phone settings."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy — tap start again."
                    SpeechRecognizer.ERROR_AUDIO -> "Microphone is in use by another app."
                    else -> "Could not hear anything. Tap start again."
                }
                wantListening = false
                _state.value = _state.value.copy(listening = false, error = message)
            }

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    segmentCounter++
                    val merged = listOf(_state.value.finalText, text).filter { it.isNotBlank() }.joinToString(" ")
                    _state.value = _state.value.copy(finalText = merged, partialText = "", lastSegment = text)
                }
                if (wantListening) launchRecognizer() else _state.value = _state.value.copy(listening = false)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) _state.value = _state.value.copy(partialText = text)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(buildIntent())
    }

    private fun buildIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
    }
}
