package com.teresapharmacy.quickcall.ui.nav

object Routes {
    const val HOME = "home"
    const val RECORD = "record"
    const val SEARCH = "search"
    const val PATIENT = "patient/{patientId}"
    const val OPEN_CALLS = "openCalls"
    const val SETTINGS = "settings"

    fun patient(id: String) = "patient/$id"
}
