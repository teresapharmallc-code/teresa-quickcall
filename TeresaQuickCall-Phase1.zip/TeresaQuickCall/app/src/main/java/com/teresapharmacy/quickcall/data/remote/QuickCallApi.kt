package com.teresapharmacy.quickcall.data.remote

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Url
import java.util.concurrent.TimeUnit

interface QuickCallApi {
    /**
     * The deployment URL is supplied per call because the owner sets it in Settings.
     * Apps Script answers a POST with a 302 to script.googleusercontent.com; OkHttp
     * follows that redirect automatically.
     */
    @POST
    suspend fun post(@Url url: String, @Body body: ApiRequest): ApiResponse

    companion object {
        fun create(): QuickCallApi {
            val client = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(40, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()
            return Retrofit.Builder()
                // Never used: every call passes a full @Url. Retrofit just requires a base.
                .baseUrl("https://script.google.com/")
                .client(client)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(QuickCallApi::class.java)
        }
    }
}
