package com.teresapharmacy.quickcall.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.LocalTime

class DateParserTest {
    private val today = LocalDate.of(2026, 9, 7)

    @Test fun monthFirst() = assertEquals(LocalDate.of(1965, 3, 12), DateParser.findAbsolute("march 12th, 1965", today)?.date)
    @Test fun dayFirst() = assertEquals(LocalDate.of(1958, 7, 8), DateParser.findAbsolute("8th of july 1958", today)?.date)
    @Test fun numericTwoDigitYear() = assertEquals(LocalDate.of(1965, 3, 12), DateParser.findAbsolute("3/12/65", today)?.date)
    @Test fun inTwoWeeks() = assertEquals(today.plusWeeks(2), DateParser.findRelative("in two weeks", today)?.date)
    @Test fun nextWednesday() = assertEquals(LocalDate.of(2026, 9, 9), DateParser.findRelative("on wednesday", today)?.date)
    @Test fun time1030pm() = assertEquals(LocalTime.of(22, 30), DateParser.findTime("at 10:30 pm")?.time)
    @Test fun bareNumberIsNotTime() = assertNull(DateParser.findTime("needs 3 boxes"))
}
