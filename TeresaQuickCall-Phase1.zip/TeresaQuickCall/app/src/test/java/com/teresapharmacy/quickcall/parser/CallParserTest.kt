package com.teresapharmacy.quickcall.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CallParserTest {

    private val today: LocalDate = LocalDate.of(2026, 9, 7) // a Monday

    @Test
    fun parsesTheSpecExampleSentence() {
        val p = CallParser.parse(
            "John Smith, date of birth March 12 1965, calling about wheelchair. Insurance needs clinical notes. Call him back tomorrow. Phone number 718-555-1234.",
            today
        )
        assertEquals("John Smith", p.patientName)
        assertEquals("03/12/1965", p.dob)
        assertEquals("718-555-1234", p.phone)
        assertEquals("Wheelchair", p.product)
        assertEquals("09/08/2026", p.callbackDate)
        assertEquals("Callback required", p.status)
        assertTrue(p.actionRequired.contains("clinical notes"))
        assertTrue(p.actionRequired.contains("call back"))
        assertEquals("Insurance problem", p.category)
        assertEquals("Normal", p.priority)
    }

    @Test
    fun parsesNumericDobAndSpokenPhone() {
        val p = CallParser.parse("Maria Lopez DOB 7/8/1958 phone 718 555 9876 calling about lisinopril refill", today)
        assertEquals("Maria Lopez", p.patientName)
        assertEquals("07/08/1958", p.dob)
        assertEquals("718-555-9876", p.phone)
        assertEquals("Lisinopril refill", p.product)
        assertEquals("Refill", p.category)
    }

    @Test
    fun callbackWithTimeAndWeekday() {
        val p = CallParser.parse("Call the patient back Friday at 3", today)
        assertEquals("09/11/2026", p.callbackDate)
        assertEquals("3:00 PM", p.callbackTime)
        assertEquals("Callback required", p.status)
    }

    @Test
    fun callbackTomorrowAtTenAm() {
        val p = CallParser.parse("Ana Ruiz needs insurance, call tomorrow at 10 AM", today)
        assertEquals("Ana Ruiz", p.patientName)
        assertEquals("09/08/2026", p.callbackDate)
        assertEquals("10:00 AM", p.callbackTime)
        assertEquals("Insurance problem", p.category)
    }

    @Test
    fun urgentAndCompletedStatuses() {
        val u = CallParser.parse("Bob Lee urgent prior authorization needed", today)
        assertEquals("Urgent", u.priority)
        assertEquals("Prior authorization", u.category)
        val c = CallParser.parse("Bob Lee walker is ready for pickup, completed", today)
        assertEquals("Completed", c.status)
        assertEquals("Ready for pickup", c.category)
    }

    @Test
    fun blankFieldsAreNotInvented() {
        val p = CallParser.parse("calling about a shower chair", today)
        assertEquals("", p.patientName)
        assertEquals("", p.dob)
        assertEquals("", p.phone)
        assertEquals("", p.callbackDate)
        assertEquals("Shower chair", p.product)
        assertEquals("New", p.status)
    }

    @Test
    fun emptyInputGivesEmptyResult() {
        assertEquals(ParsedCall(), CallParser.parse("", today))
    }
}
