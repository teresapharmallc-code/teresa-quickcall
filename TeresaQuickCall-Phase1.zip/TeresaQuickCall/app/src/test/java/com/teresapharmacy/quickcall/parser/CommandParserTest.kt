package com.teresapharmacy.quickcall.parser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandParserTest {
    @Test fun detectsSave() = assertEquals(CommandParser.Command.SAVE, CommandParser.detect("Save call."))
    @Test fun detectsCancel() = assertEquals(CommandParser.Command.CANCEL, CommandParser.detect("cancel"))
    @Test fun detectsNewCall() = assertEquals(CommandParser.Command.NEW_CALL, CommandParser.detect("New call"))
    @Test fun detectsUrgent() = assertEquals(CommandParser.Command.MARK_URGENT, CommandParser.detect("mark urgent"))
    @Test fun ignoresNormalSpeech() = assertNull(CommandParser.detect("call him back tomorrow and save the notes"))
    @Test fun confirmationYes() = assertEquals(CommandParser.Confirmation.YES, CommandParser.detectConfirmation("Yes"))
    @Test fun confirmationNo() = assertEquals(CommandParser.Confirmation.NO, CommandParser.detectConfirmation("no, fix"))
}
