# Keep API models (Moshi uses Kotlin reflection for these classes)
-keep class com.teresapharmacy.quickcall.data.remote.** { *; }
-keepclassmembers class kotlin.Metadata { *; }
-keep class kotlin.reflect.jvm.internal.** { *; }
-dontwarn org.jetbrains.annotations.**
# Room
-keep class * extends androidx.room.RoomDatabase
# Never keep line-number-based logging of patient data; strip Log calls in release
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}
